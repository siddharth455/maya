<?php
$page_title = "B.Voc Patient Healthcare in Dehradun | Maya Devi University";
$page_description = "Enroll in B.Voc Patient Healthcare at Maya Devi University, Dehradun with hospital-based training and hands-on clinical exposure.";
$canonical_url = "https://maya.edu.in/b.voc-patient-healthcare.php";
$og_image = "https://maya.edu.in/assets/uploads/campus-2.jpeg";
?>
<?php require "common/header.php" ?>
<div class="breadcrumb-area">
    <div class="breadcrumb-top default-overlay bg-img breadcrumb-overly-2 pt-100 pb-95" style="background-image:url(assets/uploads/patient.webp);">
        <div class="container">
            <h2>B.Voc Patient & Health Care Management</h2>
            <p>The Patient & Health Care Management program prepares students for administrative and support roles in healthcare settings.It covers patient care protocols, medical records management, and healthcare ethics.</p>
        </div>
    </div>
    <div class="breadcrumb-bottom">
        <div class="container">
            <ul>
                <li><a href="index.php">Home</a> <span><i class="fa fa-angle-double-right"></i></span></li>
            </ul>
        </div>
    </div>
</div>
<div class="course-details-area pt-130">
    <div class="container">
        <div class="row">
            <div class="col-xl-9 col-lg-8">
                <div class="course-left-wrap mr-40">
                    <div class="apply-area">
                        <img src="assets/uploads/patient.webp" alt="">
                        <div class="course-apply-btn">
                            <a href="https://admissions.maya.edu.in" class="default-btn">APPLY NOW</a>
                        </div>
                    </div>
                    <div class="tab-content jump">
                        <div class="tab-pane active mt-5" id="course-details-1">
                            <div class="over-view-content">
                                <h4>COURSE DETAILS</h4>
                                <h5>Course Name : B.Voc Patient & Health Care Management</h5>
                                <p>The Bachelor of Vocation (B.Voc) in Patient & Health Care Management program equips students with practical knowledge and professional skills essential for effective healthcare service delivery and hospital administration. The curriculum integrates theoretical learning with hands-on training in patient care, hospital operations, medical record management, healthcare communication, and quality assurance. Students develop strong organizational, managerial, and interpersonal skills required to ensure efficient and compassionate healthcare services.</p> <p>Through internships, clinical exposure, and collaborations with hospitals and healthcare organizations, learners gain real-world experience in patient management, healthcare coordination, and administrative processes. The program emphasizes professionalism, empathy, and ethical healthcare practices, preparing graduates for careers as patient care coordinators, healthcare administrators, hospital assistants, and medical office managers in hospitals, clinics, and healthcare institutions.</p>
                                <div class="over-view-list">
                                    <h2>Eligibility Criteria</h2>
                                    <div class="sin-over-view-list">

                                        <div class="course-list-icon">
                                            <i class="fa fa-check"></i>
                                        </div>
                                        <div class="course-list-content">
                                            <p>10+2 in any stream from any recognized board.</p>
                                        </div>
                                    </div>
                                    <div class="sin-over-view-list">
                                        <div class="course-list-icon">
                                            <i class="fa fa-check"></i>
                                        </div>
                                        <div class="course-list-content">
                                            <p>Minimum 45% marks for General category</p>
                                        </div>
                                    </div>
                                    <div class="sin-over-view-list">
                                        <div class="course-list-icon">
                                            <i class="fa fa-check"></i>
                                        </div>
                                        <div class="course-list-content">
                                            <p>Minimum 40% marks for SC/ST category</p>
                                        </div>
                                    </div>
                                </div>
                                <h2>More Details</h2>
                                <div class="course-summary-wrap mt-4">

                                    <div class="single-course-summary">
                                        <h4>Total Students</h4>
                                        <span><i class="fa fa-user"></i> 60</span>
                                    </div>
                                    <div class="single-course-summary">
                                        <h4>Course Duration</h4>
                                        <span><i class="fa fa-clock-o"></i> 3years</span>
                                    </div>
                                    <div class="single-course-summary">
                                        <h4>Course Credits</h4>
                                        <span><i class="fa fa-diamond"></i> 125</span>
                                    </div>
                                    <div class="single-course-summary">
                                        <h4>Total Semester</h4>
                                        <span><i class="fa fa-book"></i> 6</span>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>

                    <div class="related-course pt-70">
                        <div class="related-title mb-45 mrg-bottom-small">
                            <h3>Related Course</h3>

                        </div>
                        <div class="related-slider-active">
                        <div class="single-course">
                                <div class="course-img">
                                <a href="b.voc-agriculture.php"><img class="animated" src="assets/uploads/agri.webp" alt=""></a>
                                </div>
                                <div class="course-content">
                                    <h4><a href="b.voc-agriculture.php">B.Voc Agriculture</a></h4>
                                    <p>The Agriculture program is designed to equip students with practical skills in modern agricultural practices, sustainable farming, and agri-business.</p>
                                </div>
                                <div class="course-position-content">
                                    <div class="credit-duration-wrap">
                                        <div class="sin-credit-duration">
                                            <i class="fa fa-diamond"></i>
                                            <span>Credits : 125</span>
                                        </div>
                                        <div class="sin-credit-duration">
                                            <i class="fa fa-clock-o"></i>
                                            <span>Duration : 3yrs</span>
                                        </div>
                                    </div>
                                    <div class="course-btn">
                                        <a class="default-btn" href="b.voc-agriculture.php">APPLY NOW</a>
                                    </div>
                                </div>
                            </div>
                            <div class="single-course">
                                <div class="course-img">
                                <a href="b.voc-aviation.php"><img class="animated" src="assets/uploads/aviation.webp" alt=""></a>
                                </div>
                                <div class="course-content">
                                    <h4><a href="b.voc-aviation.php">B.Voc Aviation</a></h4>
                                    <p>The Aviation program prepares students for dynamic careers in the airline and airport industry.</p>
                                </div>
                                <div class="course-position-content">
                                    <div class="credit-duration-wrap">
                                        <div class="sin-credit-duration">
                                            <i class="fa fa-diamond"></i>
                                            <span>Credits : 125</span>
                                        </div>
                                        <div class="sin-credit-duration">
                                            <i class="fa fa-clock-o"></i>
                                            <span>Duration : 3yrs</span>
                                        </div>
                                    </div>
                                    <div class="course-btn">
                                        <a class="default-btn" href="b.voc-aviation.php">APPLY NOW</a>
                                    </div>
                                </div>
                            </div>
                            <div class="single-course">
                                <div class="course-img">
                                    <a href="b.voc-pharma-assistance.php"><img class="animated" src="assets/uploads/pharmacy.webp" alt=""></a>
                                </div>
                                <div class="course-content">
                                    <h4><a href="b.voc-pharma-assistance.php">B.Voc Pharma Assistance</a></h4>
                                <p>The Pharma Assistance program trains students in the essential operations of pharmaceutical services, including drug dispensing, inventory management, and patient care.</p>
                                </div>
                                <div class="course-position-content">
                                    <div class="credit-duration-wrap">
                                        <div class="sin-credit-duration">
                                            <i class="fa fa-diamond"></i>
                                            <span>Credits : 125</span>
                                        </div>
                                        <div class="sin-credit-duration">
                                            <i class="fa fa-clock-o"></i>
                                            <span>Duration : 3yrs</span>
                                        </div>
                                    </div>
                                    <div class="course-btn">
                                        <a class="default-btn" href="b.voc-pharma-assistance.php">APPLY NOW</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <div class="col-xl-3 col-lg-4">
                <div class="sidebar-style sidebar-res-mrg-none">

                    <div class="sidebar-about mb-40">
                        <div class="sidebar-title mb-15">
                            <h4>About Us</h4>
                        </div>
                        <p>The Bachelor of Vocation (B.Voc) in Patient & Health Care Management program at Maya Devi University offers a skill-based and industry-oriented curriculum designed to prepare students for professional careers in healthcare administration, patient care services, and hospital management. The program combines classroom learning with practical training in hospital operations, medical record management, patient relations, and healthcare coordination. Students develop strong organizational, communication, and managerial skills required to excel as healthcare administrators, patient care executives, and hospital support professionals in hospitals, clinics, and healthcare institutions.</p>
                    </div>

                    <div class="sidebar-category mb-40">
                        <div class="sidebar-title mb-40">
                            <h4>School Category</h4>
                        </div>
                        <div class="category-list">
                            <ul>
                                <li><a href="best-engineering-college-in-dehradun-Uttarakhand.php">School of Engineering <span>13</span></a></li>
                                <li><a href="pharmacy.php">School of Pharmacy <span>07</span></a></li>
                                <li><a href="Nursing.php">School of Nursing <span>03</span></a></li>
                                <li><a href="management-and-commerce.php">School of Commerce & Management <span>09</span></a></li>
                                <li><a href="School-Of-Health-Sciences.php">School of Health Sciences <span>10</span></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="sidebar-recent-course-wrap mb-40">
                        <div class="sidebar-title mb-40">
                            <h4>Key Features</h4>
                        </div>
                        <div class="over-view-list">

                            <div class="sin-over-view-list">

                                <div class="course-list-icon">
                                    <i class="fa fa-check"></i>
                                </div>
                                <div class="course-list-content">
                                    <p>Understand healthcare protocols.</p>
                                </div>
                            </div>
                            <div class="sin-over-view-list">
                                <div class="course-list-icon">
                                    <i class="fa fa-check"></i>
                                </div>
                                <div class="course-list-content">
                                    <p>Manage patient data and services.</p>
                                </div>
                            </div>
                            <div class="sin-over-view-list">
                                <div class="course-list-icon">
                                    <i class="fa fa-check"></i>
                                </div>
                                <div class="course-list-content">
                                    <p>Coordinate hospital operations.</p>
                                </div>
                            </div>
                            <div class="sin-over-view-list">
                                <div class="course-list-icon">
                                    <i class="fa fa-check"></i>
                                </div>
                                <div class="course-list-content">
                                    <p>Ensure compliance with health regulations.</p>
                                </div>
                            </div>
                            <div class="sin-over-view-list">
                                <div class="course-list-icon">
                                    <i class="fa fa-check"></i>
                                </div>
                                <div class="course-list-content">
                                    <p>Use health IT systems effectively.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="over-view-list">
                        <div class="sidebar-title mb-40">
                            <h4>Career Prospects</h4>
                        </div>
                        <div class="sin-over-view-list">

                            <div class="course-list-icon">
                                <i class="fa fa-check"></i>
                            </div>
                            <div class="course-list-content">
                                <p>Hospital administrator</p>
                            </div>
                        </div>
                        <div class="sin-over-view-list">
                            <div class="course-list-icon">
                                <i class="fa fa-check"></i>
                            </div>
                            <div class="course-list-content">
                                <p>Patient coordinator </p>
                            </div>
                        </div>
                        <div class="sin-over-view-list">
                            <div class="course-list-icon">
                                <i class="fa fa-check"></i>
                            </div>
                            <div class="course-list-content">
                                <p>Medical records officer</p>
                            </div>
                        </div>
                        <div class="sin-over-view-list">
                            <div class="course-list-icon">
                                <i class="fa fa-check"></i>
                            </div>
                            <div class="course-list-content">
                                <p>Healthcare support executive</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php require "application-process.php" ?>
<div class="brand-logo-area pt-45 pb-130">
    <div class="container">
        <h2 class="text-center mt-3 mb-3">Industry Partner</h2>
        <div class="brand-logo-active owl-carousel">
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/1.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/2.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/3.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/4.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/5.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/6.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/7.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/8.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/9.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/10.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/11.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/12.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/13.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/14.webp" alt="brand-logo">
            </div>
        </div>
    </div>
</div>

<?php require "common/footer.php" ?>
<style>
    .single-brand-logo img {
        width: 150px;
        height: 100px;
        object-fit: contain;
        display: block;
        margin: auto;
    }
</style>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<script>
    $(document).ready(function() {
        $('.brand-logo-active').owlCarousel({
            loop: true,
            margin: 20,
            autoplay: true,
            autoplayTimeout: 2000,
            autoplayHoverPause: true,
            smartSpeed: 800,
            responsive: {
                0: {
                    items: 2
                },
                600: {
                    items: 4
                },
                1000: {
                    items: 6
                }
            }
        });
    });
</script>