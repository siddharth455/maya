<!doctype html>
<html class="no-js" lang="zxx">

<head>
<title><?php echo $page_title ?? "Maya Devi University | Best Private University in Dehradun"; ?></title>

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<meta name="description" content="<?php echo $page_description ?? "Maya Devi University is a leading private university in Dehradun offering Engineering, Management, Pharmacy, Nursing and more."; ?>">

<link rel="canonical" href="<?php echo $canonical_url ?? "https://maya.edu.in/"; ?>">

<meta property="og:locale" content="en_IN" />
<meta property="og:type" content="website" />
<meta property="og:title" content="<?php echo $page_title ?? "Maya Devi University"; ?>" />
<meta property="og:description" content="<?php echo $page_description ?? "Leading private university in Dehradun."; ?>" />
<meta property="og:url" content="<?php echo $canonical_url ?? "https://maya.edu.in/"; ?>" />
<meta property="og:site_name" content="Maya Devi University" />
<meta property="og:image" content="<?php echo $og_image ?? "https://maya.edu.in/assets/uploads/campus-2.jpeg"; ?>" />
<meta property="og:image:width" content="1200"/>
<meta property="og:image:height" content="630"/>

<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?php echo $page_title ?? "Maya Devi University"; ?>">
<meta name="twitter:description" content="<?php echo $page_description ?? "Top university in Dehradun offering multiple programs."; ?>">
<meta name="twitter:image" content="<?php echo $og_image ?? "https://maya.edu.in/assets/uploads/campus-2.jpeg"; ?>">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/uploads/logo/favicon-CqYW0pAm.ico">

    <!-- CSS
	============================================ -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Icon Font CSS -->
    <link rel="stylesheet" href="assets/css/icons.min.css">
    <!-- Plugins CSS -->
    <link rel="stylesheet" href="assets/css/plugins.css">
    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr-3.11.7.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" />
    
<script type="application/ld+json">
{
 "@context": "https://schema.org",
 "@type": "CollegeOrUniversity",
 "name": "Maya Devi University",
 "url": "https://maya.edu.in",
 "address": {
   "@type": "PostalAddress",w
   "addressLocality": "Dehradun",
   "addressCountry": "India"
 }
}
</script>
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-QVTKG6K0PZ"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-QVTKG6K0PZ');
</script>
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '244750689907885');
  fbq('track', 'PageView');
  </script>
</head>

<body>
    <!-- Meta Pixel noscript -->
  <noscript>
    <img height="1" width="1" style="display:none"
    src="https://www.facebook.com/tr?id=244750689907885&ev=PageView&noscript=1"/>
  </noscript>
    <?php
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "https://";
$host = $_SERVER['HTTP_HOST'];

// Detect project folder (for localhost)
$projectFolder = str_replace(basename($_SERVER['SCRIPT_NAME']), '', $_SERVER['SCRIPT_NAME']);

// Final base URL
$base_url = $protocol . $host . $projectFolder;
?>
    <header class="header-area">
        <div class="header-top bg-img">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-7 col-12 col-sm-8">
                        <div class="header-contact">
                            <ul>
                                <li><i class="fa fa-phone"></i> 0135-2658602</li>
                                <li><i class="fa fa-envelope-o"></i><a href="#">info@maya.edu.in</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-5 col-12 col-sm-4">
                        <div class="login-register">
                            <ul>
                                <li><a href="contact.php">Contact us</a></li>
                                <li><a href="university-recognition.php">University Recognition</a></li>
                                <li><a href="blog.php"> BLOG </a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-bottom sticky-bar clearfix">
            <div class="container-fluid px-lg-5 px-3">
                <div class="row align-items-center flex-lg-nowrap">
                    <div class="col-lg-auto col-md-6 col-4">
                        <div class="logo">
                            <a href="index.php">
                                <img alt="" src="assets/uploads/logo/logo-2.png">
                            </a>
                        </div>
                    </div>
                    <div class="col-lg col-md-6 col-8">
                        <div class="menu-cart-wrap">
                            <div class="main-menu">
                                <nav>
                                    <ul>
                                        <li><a href="index.php"> HOME </a>

                                        </li>
                                        <li><a href="#"> ABOUT US <i class="fa fa-angle-down"></i> </a>
                                            <ul class="submenu">
                                                <li><a href="about-us.php">About University</a></li>
                                                <li><a href="governance.php">About Governance</a></li>
                                                <li><a href="committees.php">About Committees</a></li>
                                                <li><a href="offices-services.php">Offices & Services</a></li>
                                                 <li><a href="leadership.php">Leadership</a></li>
                                                <li><a href="vision-mission.php">Vision and Mission</a></li>
                                                <li><a href="approval-accredetion-membership-ranking.php">Approval, Accredetions<br> & Ranking</a></li>
                                            </ul>
                                        </li>
                                        <li class="mega-menu-position top-hover"><a href="#"> OUR SCHOOLS <i class="fa fa-angle-down"></i> </a>
                                            <ul class="mega-menu">
                                                <li>
                                                    <ul>
                                                        <li><a href=""></a></li>
                                                        <li><a href="best-computer-engineering-college-in-dehradun-uttarakhand.php">School of Computer Engineering &<br> Applications</a></li>
                                                        <li><a href="best-engineering-college-in-dehradun-uttarakhand.php">School of Engineering</a></li>
                                                        <li><a href="pharmacy.php">School of Pharmacy</a></li>
                                                        <li><a href="management-and-commerce.php">School of Commerce & Management</a></li>
                                                        <li><a href="hotel-management-and-tourism.php">School of Hotel Management & Tourism</a></li>
                                                        <li><a href="sciences.php">School of Life & Applied Science</a></li>
                                                    </ul>
                                                </li>
                                                <li>
                                                    <ul>
                                                        <li><a href=""></a></li>
                                                        <li><a href="School-Of-Education.php">School of Education</a></li>
                                                        <li><a href="agriculture.php">School of Agriculture & Technology</a></li>
                                                        <li><a href="Nursing.php">School of Nursing</a></li>
                                                        <li><a href="School-Of-Health-Sciences.php">School of Health Sciences</a></li>
                                                        <li><a href="School-Of-Paramedical-Sciences.php">School of Paramedical Sciences</a></li>
                                                        <li><a href="Arts-and-humanities.php">School of Arts & Humanities</a></li>
                                                    </ul>
                                                </li>
                                                <li>
                                                    <ul>
                                                        <li><a href=""></a></li>
                                                        <li><a href="School-Of-LegalStudies.php">School of Law & Legal Studies</a></li>
                                                        <li><a href="School-Of-Skill-Development-and-Vocational-Studies.php">School of Skill Development & Vocational Studies</a></li>
                                                        <li><a href="School-Of-Rehabilitation-Sciences.php">Ashtvakra School of Rehabilitation</a></li>
                                                    </ul>
                                                </li>

                                            </ul>
                                        </li>
                                        <li><a href="#"> ADMISSION <i class="fa fa-angle-down"></i> </a>
                                            <ul class="submenu">
                                                <li><a href="assets/uploads/pdf/MDU_COMBINED_Brochure.pdf" download="MDU_COMBINED_Brochure.pdf">MDU Brocure</a></li>
                                                <li><a href="fee-structure.php">Fee Structure</a></li>
                                                <li><a href="https://admissions.maya.edu.in" target="_blank">Apply Now</a></li>
                                                <li><a href="campus-life.php">Campus Life</a></li>
                                                <li><a href="assets/uploads/pdf/List_of_Holidays_2026.pdf" download="List_of_Holidays_2025.pdf">List of Holidays</a></li>
                                                <li><a href="assets/uploads/pdf/Academic-Calender_2025-26.pdf" download="Academic_Calender_Even_Sem_2024-25.pdf">Academic Calender<br> Even Sem 2024-25</a></li>
                                                <li><a href="refund-policy.php">Refund Policy</a></li>
                                            </ul>
                                        </li>
                                         <li><a href="#"> ACADEMICS <i class="fa fa-angle-down"></i> </a>
                                            <ul class="submenu">
                                               <li><a href="colleges-departments.php">Colleges & Departments</a></li>
                                                <li><a href="university-library.php">Library</a></li>
                                                <!-- <li><a href="" download="MDU_COMBINED_Brochure.pdf">Academic Overview</a></li>
                                                <li><a href="" target="_blank">Curriculum Innovation</a></li>
                                                <li><a href="">Examination</a></li>
                                                <li><a href="" download="Academic_Calender_Even_Sem_2024-25.pdf">Academic Calender</a></li>
                                                <li><a href="">List of Holidays</a></li> -->
                                            </ul>
                                        </li>
                                        <li><a href="#"> COURSES/PROGRAMMES <i class="fa fa-angle-down"></i> </a>
                                            <ul class="submenu">
                                                <li><a href="Diploma-course.php">Diploma Courses</a></li>
                                                <li><a href="undergraduate-course.php">Undergraduate Courses</a></li>
                                                <li><a href="post-graduate.php">Post Graduate Courses</a></li>
                                                 <li><a href="best-university-for-phd-in-dehradun-uttarakhand.php">PHD</a></li>
                                            </ul>
                                        </li>
                                          <li><a href="research.php">RESEARCH</a></li>
                                        
                                        <li><a href="placement-overview.php"> PLACEMENT </a></li>
                                    </ul>
                                </nav>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="mobile-menu-area">
                    <div class="mobile-menu">
                        <nav id="mobile-menu-active">
                            <ul class="menu-overflow">
                                <li><a href="index.php">HOME</a>
                                </li>
                                <li>
                                   <a href="#">ABOUT US<i class="fa fa-angle-down"></i></a>
                                            <ul class="submenu">
                                                <li><a href="about-us.php">About University</a></li>
                                                <li><a href="governance.php">About Governance</a></li>
                                                <li><a href="committees.php">About Committees</a></li>
                                                <li><a href="offices-services.php">Offices & Services</a></li>
                                                 <li><a href="leadership.php">Leadership</a></li>
                                                <li><a href="vision-mission.php">Vision and Mission</a></li>
                                                <li><a href="approval-accredetion-membership-ranking.php">Approval, Accredetions & Ranking</a></li>
                                            </ul>
                                        </li>
                                <li><a href="#"> OUR SCHOOLS <i class="fa fa-angle-down"></i> </a>
                                    <ul class="submenu">
                                        <li><a href="best-computer-engineering-college-in-dehradun-uttarakhand.php">School of Computer Engineering & Applications</a></li>
                                        <li><a href="best-engineering-college-in-dehradun-uttarakhand.php">School of Engineering</a></li>
                                        <li><a href="pharmacy.php">School of Pharmacy</a></li>
                                        <li><a href="management-and-commerce.php">School of Commerce & Management</a></li>
                                        <li><a href="hotel-management-and-tourism.php">School of Hotel Management & Tourism</a></li>
                                        <li><a href="sciences.php">School of Life & Applied Science</a></li>
                                        <li><a href="School-Of-Education.php">School of Education</a></li>
                                        <li><a href="agriculture.php">School of Agriculture & Technology</a></li>
                                        <li><a href="Nursing.php">School of Nursing</a></li>
                                        <li><a href="School-Of-Health-Sciences.php">School of Health Sciences</a></li>
                                        <li><a href="School-Of-Paramedical-Sciences.php">School of Paramedical Sciences</a></li>
                                        <li><a href="Arts-and-humanities.php">School of Arts & Humanities</a></li>
                                        <li><a href="School-Of-LegalStudies.php">School of Law & Legal Studies</a></li>
                                        <li><a href="School-Of-Skill-Development-and-Vocational-Studies.php">School of Skill Development & Vocational Studies</a></li>
                                        <li><a href="School-Of-Rehabilitation-Sciences.php">Ashtvakra School of Rehabilitation</a></li>
                                    </ul>
                                </li>
                                <li><a href="#"> ADMISSION <i class="fa fa-angle-down"></i> </a>
                                    <ul class="submenu">
                                        <li><a href="assets/uploads/pdf/MDU_COMBINED_Brochure.pdf" download="MDU_COMBINED_Brochure.pdf">MDU Brocure</a></li>
                                        <li><a href="fee-structure.php">Fee Structure</a></li>
                                        <li><a href="https://admissions.maya.edu.in" target="_blank">Apply Now</a></li>
                                        <li><a href="campus-life.php">Campus Life</a></li>
                                        <li><a href="assets/uploads/pdf/List_of_Holidays_2025.pdf" download="List_of_Holidays_2025.pdf">List of Holidays</a></li>
                                        <li><a href="assets/uploads/pdf/Academic_Calender_Even_Sem_2024-25.pdf" download="Academic_Calender_Even_Sem_2024-25.pdf">Academic Calender Even Sem 2024-25</a></li>
                                        <li><a href="refund-policy.php">Refund Policy</a></li>
                                    </ul>
                                </li>
 <li><a href="#"> ACADEMICS <i class="fa fa-angle-down"></i> </a>
                                            <ul class="submenu">
                                                <li><a href="colleges-departments.php">Colleges & Departments</a></li>
                                                <li><a href="university-library.php">Library</a></li>
                                                <!-- <li><a href="" download="MDU_COMBINED_Brochure.pdf">Academic Overview</a></li>
                                                <li><a href="" target="_blank">Curriculum Innovation</a></li>
                                                <li><a href="">Examination</a></li>
                                                <li><a href="" download="Academic_Calender_Even_Sem_2024-25.pdf">Academic Calender</a></li>
                                                <li><a href="">List of Holidays</a></li> -->
                                            </ul>
                                        </li>
                                <li><a href="#"> COURSES/PROGRAMMES <i class="fa fa-angle-down"></i> </a>
                                            <ul class="submenu">
                                                <li><a href="Diploma-course.php">Diploma Courses</a></li>
                                                <li><a href="undergraduate-course.php">Undergraduate Courses</a></li>
                                                <li><a href="post-graduate.php">Post Graduate Courses</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="research.php">RESEARCH</a></li>
                                <li><a href="blog.php">BLOG</a>
                                </li>
                                <li><a href="placement-overview.php">PLACEMENT</a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>


   <script>
(function () {

  function activateMobileMenu() {

    const menu = document.querySelector('.mobile-menu-area');
    if (!menu) return;

    // CAPTURE phase → runs before theme/plugin JS
    menu.addEventListener('click', function (e) {

      const link = e.target.closest('a');
      if (!link) return;

      const li = link.closest('li');
      if (!li) return;

      const submenu = li.querySelector('ul');
      if (!submenu) return;

      // Stop EVERYTHING else
      e.preventDefault();
      e.stopImmediatePropagation();

      // Close other open menus
      menu.querySelectorAll('li.force-open').forEach(el => {
        if (el !== li) el.classList.remove('force-open');
      });

      // Toggle current
      li.classList.toggle('force-open');

    }, true); // 👈 CAPTURE PHASE (KEY)

  }

  // Run immediately
  activateMobileMenu();

  // ALSO watch for menu re-render by plugins.js
  const observer = new MutationObserver(activateMobileMenu);
  observer.observe(document.body, { childList: true, subtree: true });

})();
</script>

    <style>
        /* ===== FIX DESKTOP CLICK ISSUE CAUSED BY STICKY HEADER ===== */

/* Ensure header stays on top but does NOT block clicks below */
.header-bottom {
  position: relative;
  z-index: 999;
}

/* When sticky is active */
.header-bottom.is-sticky {
  position: fixed;
  top: 0;
  width: 100%;
  height: auto;
}

/* Disable invisible overlay from sticky header */
.header-bottom::before,
.header-bottom::after {
  pointer-events: none;
}
/* ==============================
   MOBILE MENU – FORCE DROPDOWN
/* ===============================
   MOBILE MENU – FORCE OPEN
   =============================== */
@media (max-width: 991px) {

  .mobile-menu-area ul ul {
    display: none !important;
  }

  .mobile-menu-area li.force-open > ul {
    display: block !important;
  }

}
 </style>