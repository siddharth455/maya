<?php
$page_title = "School of Rehabilitation Sciences | Maya Devi University Dehradun";
$page_description = "School of Rehabilitation Sciences at Maya Devi University, Dehradun offering therapy and rehabilitation programs.";
$canonical_url = "https://maya.edu.in/School-Of-Rehabilitation-Sciences.php";
$og_image = "https://maya.edu.in/assets/uploads/campus-2.jpeg";
?>
<?php require "common/header.php" ?>
<!-- Hero Section -->
<section class="hero-section" style="background: url('assets/uploads/asr.jpg') center/cover no-repeat; height:70vh;">
  <div class="hero-content">
    
  </div>
</section>

<!-- About Section -->
<section class="container py-5">
  <div class="section-title  pb-20">
    <h2>School <span>Overview</h2>
  </div>
  <div class="row">
    <!-- Left Text -->
    <div class="col-md-7">
      <p>
        The Ashtavakra School of Rehabilitation stands as a beacon of inclusive education and therapeutic excellence. Named after the revered sage Ashtavakra—whose life exemplifies resilience, wisdom, and overcoming physical limitations—the school is deeply rooted in the philosophy of empowering individuals with disabilities through education, care, and innovation.
      </p>
      <p>
        The department offers a multidisciplinary approach to rehabilitation, integrating clinical psychology, speech and hearing sciences, prosthetics and orthotics, special education, and caregiving.
      </p>
      <p>With a strong emphasis on hands-on learning, research, and fieldwork, the school collaborates with hospitals, NGOs, and international institutions to provide students with real-world exposure. Whether through therapy labs, inclusive classrooms, or outreach programs, the Ashtavakra School of Rehabilitation is committed to shaping leaders who can transform lives and advocate for a more inclusive society.</p>
    </div>
    <!-- About Section -->
    <!-- Right Image -->
    <div class="col-md-5 text-center">
      <div class="img-container">
        <img src="assets/uploads/rehab.webp"
          alt="School of Engineering"
          class="responsive-img">
      </div>
    </div>

</section>

<!-- Courses Section -->
<div class="course-area bg-light pt-60 pb-60">
  <div class="container">

    <!-- ================= DIPLOMA PROGRAMS ================= -->
    <div class="section-title text-center mb-50">
      <h2>Diploma <span>Programs</span></h2>
      <p>Specialized diploma programs in rehabilitation, therapy, and special education.</p>
    </div>

    <div class="row">

      <!-- Early Child Special Education -->
      <div class="col-lg-3 col-md-6 mb-30">
        <div class="course-card">
          <div class="course-img">
            <a href="early-child-special-edu.php">
              <img src="assets/uploads/maya_devi_img_bnr.jpeg" alt="">
            </a>
          </div>
          <div class="course-body">
            <h4>Early Child Special Edu. (Hearing Impairment)</h4>
            <p>Prepares professionals to support young children with hearing impairment during early development.</p>
            <div class="course-meta">
              <span>Credits: 125</span>
              <span>4 Years</span>
            </div>
            <a class="default-btn btn-block" href="early-child-special-edu.php">Apply Now</a>
          </div>
        </div>
      </div>

      <!-- Early Rehabilitation Therapy -->
      <div class="col-lg-3 col-md-6 mb-30">
        <div class="course-card">
          <div class="course-img">
            <a href="early-rehabilitation-therapy.php">
              <img src="assets/uploads/maya_devi_img_bnr.jpeg" alt="">
            </a>
          </div>
          <div class="course-body">
            <h4>Early Rehabilitation Therapy (Mental Retardation)</h4>
            <p>Trains rehabilitation therapy assistants for mental and developmental disabilities.</p>
            <div class="course-meta">
              <span>Credits: 125</span>
              <span>4 Years</span>
            </div>
            <a class="default-btn btn-block" href="early-rehabilitation-therapy.php">Apply Now</a>
          </div>
        </div>
      </div>

      <!-- Prosthetics & Orthotics -->
      <div class="col-lg-3 col-md-6 mb-30">
        <div class="course-card">
          <div class="course-img">
            <a href="prosthetics-orthotics.php">
              <img src="assets/uploads/maya_devi_img_bnr.jpeg" alt="">
            </a>
          </div>
          <div class="course-body">
            <h4>Prosthetics and Orthotics</h4>
            <p>RCI-guided diploma focusing on prosthetic and orthotic device development.</p>
            <div class="course-meta">
              <span>Credits: 125</span>
              <span>4 Years</span>
            </div>
            <a class="default-btn btn-block" href="prosthetics-orthotics.php">Apply Now</a>
          </div>
        </div>
      </div>

      <!-- Hearing Language & Speech -->
      <div class="col-lg-3 col-md-6 mb-30">
        <div class="course-card">
          <div class="course-img">
            <a href="hearing-language-speech.php">
              <img src="assets/uploads/maya_devi_img_bnr.jpeg" alt="">
            </a>
          </div>
          <div class="course-body">
            <h4>Hearing Language and Speech</h4>
            <p>RCI-based diploma focused on speech, hearing, and language development.</p>
            <div class="course-meta">
              <span>Credits: 125</span>
              <span>4 Years</span>
            </div>
            <a class="default-btn btn-block" href="hearing-language-speech.php">Apply Now</a>
          </div>
        </div>
      </div>

      <!-- Indian Sign Language -->
      <div class="col-lg-3 col-md-6 mb-30">
        <div class="course-card">
          <div class="course-img">
            <a href="indian-sign-language.php">
              <img src="assets/uploads/maya_devi_img_bnr.jpeg" alt="">
            </a>
          </div>
          <div class="course-body">
            <h4>Indian Sign Language</h4>
            <p>Training program designed to promote effective communication with the deaf community.</p>
            <div class="course-meta">
              <span>Credits: 125</span>
              <span>4 Years</span>
            </div>
            <a class="default-btn btn-block" href="indian-sign-language.php">Apply Now</a>
          </div>
        </div>
      </div>

    </div>

    <!-- ================= UNDERGRADUATE PROGRAM ================= -->
    <div class="section-title text-center mb-50 mt-40">
      <h2>Undergraduate <span>Program</span></h2>
      <p>Degree program focused on psychological sciences and mental health.</p>
    </div>

    <div class="row">

      <!-- B.Sc Clinical Psychology -->
      <div class="col-lg-3 col-md-6 mb-30">
        <div class="course-card">
          <div class="course-img">
            <a href="clinical-psychology.php">
              <img src="assets/uploads/maya_devi_img_bnr.jpeg" alt="">
            </a>
          </div>
          <div class="course-body">
            <h4>B.Sc. Clinical Psychology (Hons.)</h4>
            <p>Focuses on human behavior, emotional development, and psychological disorders.</p>
            <div class="course-meta">
              <span>Credits: 125</span>
              <span>4 Years</span>
            </div>
            <a class="default-btn btn-block" href="clinical-psychology.php">Apply Now</a>
          </div>
        </div>
      </div>

    </div>

    <!-- ================= CERTIFICATE PROGRAM ================= -->
    <div class="section-title text-center mb-50 mt-40">
      <h2>Certificate <span>Program</span></h2>
      <p>Short-term skill-based programs for immediate employability.</p>
    </div>

    <div class="row">

      <!-- Care Giving -->
      <div class="col-lg-3 col-md-6 mb-30">
        <div class="course-card">
          <div class="course-img">
            <a href="care-giving.php">
              <img src="assets/uploads/maya_devi_img_bnr.jpeg" alt="">
            </a>
          </div>
          <div class="course-body">
            <h4>Certificate Course in Care Giving</h4>
            <p>Practical-oriented program preparing students for hands-on caregiving roles.</p>
            <div class="course-meta">
              <span>Credits: 125</span>
              <span>Short Term</span>
            </div>
            <a class="default-btn btn-block" href="care-giving.php">Apply Now</a>
          </div>
        </div>
      </div>

    </div>

  </div>
</div>


<!-- clubs section -->
<section class="clubs-section py-5">
  <div class="container">
    <div class="section-title pb-50">
      <h2>Student <span>Clubs 🎓</span></h2>
    </div>

    <!-- Student Societies -->
    <div class="row g-4">
      <div class="col-lg-3 col-md-6 col-sm-12 d-flex">
        <div class="club-card flex-fill">
          <div class="club-icon">♿</div>
          <h5 class="club-title">Inclusive Education Club</h5>
          <p class="club-desc">Promotes awareness and advocacy for disability rights.</p>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 col-sm-12 d-flex">
        <div class="club-card flex-fill">
          <div class="club-icon">🛠️</div>
          <h5 class="club-title">Therapy Innovation Society</h5>
          <p class="club-desc">Focuses on research and development in rehabilitation tools.</p>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 col-sm-12 d-flex">
        <div class="club-card flex-fill">
          <div class="club-icon">🤟</div>
          <h5 class="club-title">Sign Language Circle</h5>
          <p class="club-desc">Offers peer-led ISL training and cultural exchange.</p>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 col-sm-12 d-flex">
        <div class="club-card flex-fill">
          <div class="club-icon">🧠</div>
          <h5 class="club-title">Mental Health Awareness Forum</h5>
          <p class="club-desc">Creates campaigns and support groups for mental health awareness.</p>
        </div>
      </div>
    </div>
  </div>
</section>



<!-- clubs section ends -->
<section class="clubs-section py-5">
  <div class="container">
    <div class="section-title pb-50">
      <h2>Career <span>Options 💼</span></h2>
    </div>

    <!-- Career Options -->
    <div class="row g-4">
      <div class="col-lg-3 col-md-6 col-sm-12 d-flex">
        <div class="club-card flex-fill">
          <div class="club-icon">🧠</div>
          <h5 class="club-title">Clinical Psychologist</h5>
          <p class="club-desc">Assesses, diagnoses, and treats emotional and behavioral issues.</p>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 col-sm-12 d-flex">
        <div class="club-card flex-fill">
          <div class="club-icon">🗣️</div>
          <h5 class="club-title">Speech Therapist</h5>
          <p class="club-desc">Helps individuals improve communication and speech disorders.</p>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 col-sm-12 d-flex">
        <div class="club-card flex-fill">
          <div class="club-icon">🦾</div>
          <h5 class="club-title">Prosthetics Technician</h5>
          <p class="club-desc">Designs, fabricates, and fits artificial limbs and assistive devices.</p>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 col-sm-12 d-flex">
        <div class="club-card flex-fill">
          <div class="club-icon">📚</div>
          <h5 class="club-title">Special Educator</h5>
          <p class="club-desc">Supports children with disabilities through customized teaching methods.</p>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 col-sm-12 d-flex">
        <div class="club-card flex-fill">
          <div class="club-icon">🤲</div>
          <h5 class="club-title">Care Giver</h5>
          <p class="club-desc">Provides assistance and care for individuals with special needs.</p>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 col-sm-12 d-flex">
        <div class="club-card flex-fill">
          <div class="club-icon">⚕️</div>
          <h5 class="club-title">Rehabilitation Specialist</h5>
          <p class="club-desc">Guides recovery plans and therapies for physical and mental well-being.</p>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 col-sm-12 d-flex">
        <div class="club-card flex-fill">
          <div class="club-icon">👂</div>
          <h5 class="club-title">Hearing Language Specialist</h5>
          <p class="club-desc">Assists individuals with hearing and communication difficulties.</p>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 col-sm-12 d-flex">
        <div class="club-card flex-fill">
          <div class="club-icon">🤟</div>
          <h5 class="club-title">Sign Language Interpreter</h5>
          <p class="club-desc">Facilitates communication between deaf and hearing communities.</p>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 col-sm-12 d-flex">
        <div class="club-card flex-fill">
          <div class="club-icon">🧑‍⚕️</div>
          <h5 class="club-title">Mental Health Professional</h5>
          <p class="club-desc">Provides therapy and counseling for mental health support.</p>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 col-sm-12 d-flex">
        <div class="club-card flex-fill">
          <div class="club-icon">💡</div>
          <h5 class="club-title">Assistive Technology Specialist</h5>
          <p class="club-desc">Develops and implements technology solutions for accessibility.</p>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 col-sm-12 d-flex">
        <div class="club-card flex-fill">
          <div class="club-icon">🏘️</div>
          <h5 class="club-title">Community Rehabilitation Worker</h5>
          <p class="club-desc">Works at the grassroots to provide disability and rehab support.</p>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 col-sm-12 d-flex">
        <div class="club-card flex-fill">
          <div class="club-icon">🔬</div>
          <h5 class="club-title">Research Assistant</h5>
          <p class="club-desc">Supports research projects in healthcare, disability, and therapy fields.</p>
        </div>
      </div>
    </div>
  </div>
</section>




<!-- Why Choose Us -->
<section class="why-choose-us py-5">
  <div class="container">
    <div class="row align-items-center mb-5">
      <div class="col-lg-7">
        <div class="section-title pb-20">
          <h2>Why <span>Choose Us 🌟 ?</span></h2>
        </div>
        <p class="text-muted">
          Choosing the right place to pursue your education is a life-changing decision—one that shapes not just your academic journey but also your personal and professional future. At the School of Computer Applications, Maya Devi University, we go beyond conventional learning by offering an ecosystem of innovation, creativity, and global opportunities.
        </p>
        <p class="text-muted">Our focus is on preparing students to thrive in a fast-evolving digital world where adaptability, critical thinking, and ethical leadership matter as much as technical expertise. With state-of-the-art infrastructure, hands-on industry exposure, and mentorship from accomplished faculty, we ensure that every learner is equipped to transform ideas into impactful realities.</p>
        <a href="https://admissions.maya.edu.in" class="btn btn-success btn-lg mt-3">Apply Now →</a>
      </div>
      <div class="col-lg-5 text-center">
        <img src="assets/uploads/computer.jpg"
          alt="Why Choose Us"
          class="img-fluid rounded shadow"
          style="max-height:380px; object-fit:cover; width:100%;">
      </div>
    </div>

    <!-- Feature Points -->
    <div class="row gy-4">
      <div class="col-md-6">
        <div class="feature-box">
          <span class="feature-icon">🚀</span>
          <h5>Excellence in Education & Innovation</h5>
          <p>
            We offer a future-ready curriculum blending theory with hands-on practice in
            AI, cybersecurity, data science, and cloud computing—ensuring students graduate
            with cutting-edge skills.
          </p>
        </div>
      </div>

      <div class="col-md-6">
        <div class="feature-box">
          <span class="feature-icon">⚖️</span>
          <h5>Ethics Meets Technology</h5>
          <p>
            Beyond technical expertise, we emphasize building responsible leaders who
            innovate with integrity, guided by strong ethical values and social responsibility.
          </p>
        </div>
      </div>

      <div class="col-md-6">
        <div class="feature-box">
          <span class="feature-icon">🌍</span>
          <h5>Global Readiness</h5>
          <p>
            International collaborations, industry exposure, and real-world projects prepare
            our students for a connected, global workforce and professional agility.
          </p>
        </div>
      </div>

      <div class="col-md-6">
        <div class="feature-box">
          <span class="feature-icon">🔬</span>
          <h5>Research & Creativity</h5>
          <p>
            Opportunities for research, innovation, and product development encourage
            exploration, experimentation, and creative problem-solving in every discipline.
          </p>
        </div>
      </div>

      <div class="col-md-6">
        <div class="feature-box">
          <span class="feature-icon">🤝</span>
          <h5>Supportive, Inclusive Environment</h5>
          <p>
            A diverse, inclusive learning culture where every student is heard, supported,
            and mentored—personally, academically, and professionally.
          </p>
        </div>
      </div>

      <div class="col-md-6">
        <div class="feature-box">
          <span class="feature-icon">📚</span>
          <h5>Commitment to Lifelong Learning</h5>
          <p>
            Education here goes beyond degrees—it builds a mindset of curiosity,
            critical thinking, and continuous growth for life.
          </p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Student Testimonials -->
<!-- Swiper CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />

<section class="container py-5">
  <div class="section-title pb-20">
    <h2>Student <span>Testimonials</span></h2>
  </div>
  <!-- Swiper Slider -->
  <div class="swiper testimonial-slider">
    <div class="swiper-wrapper">

      <!-- Testimonial 1 -->
      <div class="swiper-slide">
        <div class="testimonial text-center p-4 shadow-sm rounded bg-white">
          <img src="assets/uploads/testimoni-1.jpeg" alt="Riya Sharma" class="testimonial-img mb-3">
          <p>"The School of Engineering provided me with excellent opportunities to learn, explore, and innovate. I secured a placement at Microsoft with 42 LPA package!"</p>
          <h6 class="mt-2">- Riya Sharma (CSE)</h6>
        </div>
      </div>

      <!-- Testimonial 2 -->
      <div class="swiper-slide">
        <div class="testimonial text-center p-4 shadow-sm rounded bg-white">
          <img src="assets/uploads/testimoni-2.jpeg" alt="Arjun Verma" class="testimonial-img mb-3">
          <p>"State-of-the-art labs and practical exposure gave me an edge in the industry. Truly grateful for the faculty and support at MDU."</p>
          <h6 class="mt-2">- Arjun Verma (Mechanical)</h6>
        </div>
      </div>

      <!-- Testimonial 3 -->
      <div class="swiper-slide">
        <div class="testimonial text-center p-4 shadow-sm rounded bg-white">
          <img src="assets/uploads/testimoni-3.jpeg" alt="Student" class="testimonial-img mb-3">
          <p>"Amazing mentors and inclusive culture. I gained not only knowledge but also confidence to excel in my career."</p>
          <h6 class="mt-2">- Sneha Gupta (MCA)</h6>
        </div>
      </div>

      <!-- Testimonial 4 -->
      <div class="swiper-slide">
        <div class="testimonial text-center p-4 shadow-sm rounded bg-white">
          <img src="assets/uploads/testimoni-4.jpeg" alt="Arjun Verma" class="testimonial-img mb-3">
          <p>"State-of-the-art labs and practical exposure gave me an edge in the industry. Truly grateful for the faculty and support at MDU."</p>
          <h6 class="mt-2">- Arjun Verma (Mechanical)</h6>
        </div>
      </div>

    </div>

    <!-- Pagination -->
    <div class="swiper-pagination"></div>

  </div>
</section>
<?php
// Load blogs
$dataFile = __DIR__ . "/admin/data/blogs.json";
$blogs = file_exists($dataFile) ? json_decode(file_get_contents($dataFile), true) : [];

// SET DEPARTMENT TAG
$dept = "Ashtvakra"; // change dynamically if needed

// FILTER BLOGS BY TAG
$filteredBlogs = [];
foreach ($blogs as $id => $b) {
    if (!empty($b['tags']) && in_array(strtolower($dept), array_map('strtolower', $b['tags']))) {
        $filteredBlogs[$id] = $b;
    }
}

// LATEST BLOGS
$latestBlogs = array_slice(array_reverse($filteredBlogs, true), 0, 10, true);
?>

<?php if (!empty($latestBlogs)): ?>  <!-- 🔥 MAIN CONDITION -->

<div class="event-area bg-img default-overlay pt-10 pb-10">
    <div class="container">
        <div class="row">
            
            <div class="col-lg-12">
                <div class="section-title-3 mb-45 mrg-bottom-small">
                    <h2>Our <span>Blog</span></h2>
                    <p>Insights and updates from Maya Devi University.</p>
                </div>

                <div class="blog-active">
                    
                    <?php foreach ($latestBlogs as $id => $b):
    $img = $b['image'] ?? 'assets/img/blog/default.jpg';
    $title = $b['title'] ?? '';
    $excerpt = substr(strip_tags($b['content']), 0, 80) . '...';
    $author = $b['author'] ?? 'Admin';
    $date = $b['date'] ?? '';
    $tags = $b['tags'] ?? [];

    // ✅ SLUG
   $slugText = $b['slug'] ?? $title;
$slugText = strtolower($slugText);
$slug = preg_replace('/[^a-z0-9]+/', '-', $slugText);
$slug = trim($slug, '-');
?>
    <div class="single-blog">
        <div class="blog-img" style="height:200px; overflow:hidden;">
            <a href="blog/<?= $slug ?>">
                <img src="<?= $img ?>" alt="<?= $title ?>" style="width:100%; height:100%; object-fit:cover;">
            </a>
        </div>

        <div class="blog-content-wrap" style="display:flex; flex-direction:column; height:100%;">
            <?php if (!empty($tags)) echo "<span>" . htmlspecialchars($tags[0]) . "</span>"; ?>

            <div class="blog-content" style="flex-grow:1;">
                <h4>
                    <a href="blog/<?= $slug ?>"><?= $title ?></a>
                </h4>
                <p><?= $excerpt ?></p>

                <div class="blog-meta">
                    <ul>
                        <li><a href="#"><i class="fa fa-user"></i> <?= $author ?></a></li>
                        <li><a href="#"><i class="fa fa-comments-o"></i> 0</a></li>
                    </ul>
                </div>
            </div>

            <div class="blog-date">
                <a href="#"><i class="fa fa-calendar-o"></i> <?= $date ?></a>
            </div>
        </div>
    </div>
<?php endforeach; ?>

                </div>
            </div>

        </div>
    </div>
</div>

<?php endif; ?>  <!-- 🔥 END CONDITION -->

<style>
.blog-active .single-blog {
    display: flex;
    flex-direction: column;
    border: 1px solid #eee;
    border-radius: 8px;
    overflow: hidden;
    background: #fff;
    margin: 10px;
    height: 100%;
}

.blog-active .blog-img {
    flex: 0 0 200px;
    overflow: hidden;
}

.blog-active .blog-img img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.blog-active .blog-content-wrap {
    display: flex;
    flex-direction: column;
    flex: 1;
    padding: 15px;
}

.blog-active .blog-content {
    flex: 1;
}

.blog-active::after {
    content: "";
    display: block;
    clear: both;
}
</style>
<!-- Swiper JS -->
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

<script>
  var swiper = new Swiper(".testimonial-slider", {
    slidesPerView: 1,
    spaceBetween: 20,
    loop: true,
    autoplay: {
      delay: 4000, // 4 seconds per slide
      disableOnInteraction: false,
    },
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
    breakpoints: {
      768: {
        slidesPerView: 2
      }, // Tablet
      1024: {
        slidesPerView: 3
      } // Desktop
    }
  });
</script>
<?php require "common/footer.php" ?>