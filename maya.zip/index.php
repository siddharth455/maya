<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="icon" type="image/webp" href="assets/uploads/logo/favicon-CqYW0pAm.ico">

    <title>Best Private University in Dehradun | Maya Devi University</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="description" content="Maya Devi University is a leading private university in Dehradun, Uttarakhand offering B.Tech, B.Sc, MBA, MCA, Pharmacy, Nursing, and more with modern infrastructure, expert faculty, and strong placement support.">

    <link rel="canonical" href="https://maya.edu.in/">

    <meta property="og:locale" content="en_IN" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="Best Private University in Dehradun | Maya Devi University" />
    <meta property="og:description" content="Explore top undergraduate and postgraduate programs at Maya Devi University, Dehradun with world-class education and strong industry exposure." />
    <meta property="og:url" content="https://maya.edu.in/" />
    <meta property="og:site_name" content="Maya Devi University" />
    <meta property="og:image" content="https://maya.edu.in/assets/uploads/campus-2.jpeg" />
    <meta property="og:image:width" content="1200" />
    <meta property="og:image:height" content="630" />
    <meta property="og:image:type" content="image/webp" />

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Best Private University in Dehradun | Maya Devi University">
    <meta name="twitter:description" content="Top university in Dehradun offering Engineering, Management, Pharmacy, Nursing and more.">
    <meta name="twitter:image" content="https://maya.edu.in/assets/uploads/campus-2.jpeg">

</head>

<body>

</body>

</html>
<?php require "common/header.php" ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" />

<div class="slider-area">
    <div class="slider-active owl-carousel owl-theme">

        <!-- Slide 1 -->
        <div class="single-slider slider-height-1 bg-img" style="background-image:
linear-gradient(rgba(0,0,0,0.45), rgba(0,0,0,0.45)),
url('assets/uploads/home-banner-1.jpeg');">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-9 col-md-7 col-12">
                        <div class="slider-content slider-animated-1 pt-230">
                            <h1 class="animated">Empower. Educate. Excel.</h1>
                            <p class="animated">Maya Devi University offers quality education, expert guidance, and a vibrant campus life to prepare you for a successful future.</p>
                            <div class="slider-btn">
                                <a class="animated default-btn btn-white-color" href="contact.php">CONTACT US</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-5 col-12">
                        <!-- <div class="slider-single-img slider-animated-1">
                            <img class="animated" src="assets/uploads/banner-girl.png" alt="">
                        </div> -->
                    </div>
                </div>
            </div>
        </div>

       

        <div class="single-slider slider-height-1 bg-img" style="background-image:
linear-gradient(rgba(0,0,0,0.45), rgba(0,0,0,0.45)),
url('assets/uploads/index-banner.jpeg');">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-9 col-md-7 col-12">
                        <div class="slider-content slider-animated-1 pt-230">
                            <h1 class="animated">Celebrate. Connect. Create Memories.</h1>
                            <p class="animated">
                                Experience the pulse of Maya Devi University through electrifying fests, cultural events, competitions, and celebrations that bring talent, creativity, and campus life together.
                            </p>

                            <div class="slider-btn">
                                <a class="animated default-btn btn-white-color" href="contact.php">CONTACT US</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-5 col-12">
                        <!-- <div class="slider-single-img slider-animated-1">
                            <img class="animated" src="assets/uploads/banner-girl.png" alt="">
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
        <div class="single-slider slider-height-1 bg-img" style="background-image:
linear-gradient(rgba(0,0,0,0.45), rgba(0,0,0,0.45)),
url('assets/uploads/index-banner-2.jpeg');">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-9 col-md-7 col-12">
                        <div class="slider-content slider-animated-1 pt-230">

                            <div class="slider-btn">

                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-5 col-12">
                        <!-- <div class="slider-single-img slider-animated-1">
                            <img class="animated" src="assets/uploads/banner-girl.png" alt="">
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
        <div class="single-slider slider-height-1 bg-img" style="background-image:
linear-gradient(rgba(0,0,0,0.45), rgba(0,0,0,0.45)),
url('assets/uploads/index-banner-3.jpeg');">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-9 col-md-7 col-12">
                        <div class="slider-content slider-animated-1 pt-230">

                            <div class="slider-btn">

                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-5 col-12">
                        <!-- <div class="slider-single-img slider-animated-1">
                            <img class="animated" src="assets/uploads/banner-girl.png" alt="">
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
        <!-- Slide 2 -->
        <div class="single-slider slider-height-1 bg-img" style="background-image:
linear-gradient(rgba(0,0,0,0.45), rgba(0,0,0,0.45)),url('assets/uploads/campus-1.webp');">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-9 col-md-7 col-12">
                        <div class="slider-content slider-animated-1 pt-230">
                            <h1 class="animated">Shaping Future Leaders.</h1>
                            <p class="animated">Maya Devi University blends innovation, academic excellence, and real-world skills to prepare students for success in every field.</p>
                            <div class="slider-btn">
                                <a class="animated default-btn btn-white-color" href="contact.php">CONTACT US</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-5 col-12">
                        <!-- <div class="slider-single-img slider-animated-1">
                            <img class="animated" src="assets/uploads/girl-2.png" alt="">
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>

<!-- FIXED Slider JS -->
<script>
    $('.slider-active').owlCarousel({
        loop: true,
        items: 1,
        margin: 0,
        autoplay: true,
        autoplayTimeout: 3000,
        autoplayHoverPause: true,
        nav: false,
        dots: true,
        smartSpeed: 600,
        animateOut: 'fadeOut',
        animateIn: 'fadeIn'
    });
</script>
<div class="choose-us section-padding-1">
    <div class="container-fluid">
        <div class="row no-gutters choose-negative-mrg">
            <div class="col-lg-3 col-md-6">
                <div class="single-choose-us choose-bg-blue">
                    <div class="choose-img">
                        <img class="animated" src="assets/img/icon-img/service-1.png" alt="Scholarship">
                    </div>
                    <div class="choose-content">
                        <h3>Scholarship Facility</h3>
                        <p>Empowering dreams through financial support — turning potential into success. </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="single-choose-us choose-bg-green">
                    <div class="choose-img">
                        <img class="animated" src="assets/img/icon-img/service-2.png" alt="Doctoral">
                    </div>
                    <div class="choose-content">
                        <h3>Doctoral Program</h3>
                        <p>Advancing knowledge, shaping futures, and leading the way in research and innovation. </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="single-choose-us choose-bg-blue">
                    <div class="choose-img">
                        <img class="animated" src="assets/uploads/p-icon.jpg" style="height: 74px; width:70px" alt="Placement">
                    </div>
                    <div class="choose-content">
                        <h3>Career Placement</h3>
                        <p>Connecting talent with the right opportunities for a future-ready career. </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="single-choose-us choose-bg-green">
                    <div class="choose-img">
                        <img class="animated" src="assets/uploads/s-icon.webp" style="height: 74px; width:70px" alt="Empowering">
                    </div>
                    <div class="choose-content">
                        <h3>Bright Futures</h3>
                        <p>Empowering young minds for a lifetime of growth and success.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="about-us pb-4">
    <div class="container">

        <!-- Section Title -->
        <div class="section-title-3 section-shape-hm2-1 text-center mb-5 mt-5">
            <h2 style="font-size: 40px; color: green; font-weight: bold;">About Maya Devi University</h2>
            <style>
                .gradient {
                    font-size: 36px;
                    font-weight: 800;
                    background: linear-gradient(90deg, #00B894, #00CFFF, #0077B6);
                    -webkit-background-clip: text;
                    background-clip: text;
                    color: transparent;
                    letter-spacing: 0.2px;
                }
            </style>
            <p style="font-size: 18px;" class="fs-5 text-muted">
                Take a breathtaking aerial tour of our state-of-the-art campus, where innovation meets inspiration amidst lush greenery and modern architecture.
            </p>
        </div>

        <!-- Video & Text -->
        <div class="row align-items-center">
            <div class="col-lg-7 col-md-12 col-sm-12">
                <div class="about-img about-img-2 mr-70"
                    style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; max-width: 100%;">

                    <iframe
                        src="https://www.youtube.com/embed/Gm-KE2N_5ws?autoplay=1&mute=1&playsinline=1&rel=0"
                        title="YouTube video player"
                        style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;"
                        frameborder="0"
                        allow="autoplay; encrypted-media; picture-in-picture"
                        referrerpolicy="strict-origin-when-cross-origin"
                        allowfullscreen>
                    </iframe>

                </div>

            </div>

            <div class="col-lg-5 col-md-12">
                <div class="about-content-2">
                    <p style="font-size: 17px;" class="fs-5 text-muted">
                        Maya Devi University, Dehradun, is a premier institution dedicated to delivering world-class education and fostering holistic development.
                        Nestled in the scenic foothills of Uttarakhand, the university offers a dynamic learning environment supported by modern infrastructure,
                        experienced faculty, and industry-aligned programs. With a focus on academic excellence, research, and innovation, Maya Devi University
                        prepares students to excel in their chosen fields while nurturing values, leadership skills, and a global perspective. Our commitment
                        is to shape future-ready professionals who can contribute meaningfully to society and thrive in an ever-changing world.
                    </p>
                </div>
            </div>
        </div>

        <!-- Features Section -->
        <div class="col-lg-12 mt-5">
            <div class="container py-4">
                <div class="row text-center">

                    <!-- Modern Facilities -->
                    <div class="col-md-4 mb-4">
                        <div class="card border-0 shadow h-100 p-4">
                            <div class="card-body">
                                <h3 class="card-title fw-semibold text-success">Modern Facilities</h3>
                                <p style="font-size: 13px;" class="fs-5 text-muted">
                                    State-of-the-art laboratories, libraries, and learning spaces designed for the future.
                                </p>
                            </div>
                        </div>
                    </div>

                    <!-- Green Campus -->
                    <div class="col-md-4 mb-4">
                        <div class="card border-0 shadow h-100 p-4">
                            <div class="card-body">
                                <h3 class="card-title fw-semibold text-success">Green Campus</h3>
                                <p style="font-size: 13px;" class="fs-5 text-muted">
                                    Sustainability at the core with lush gardens, solar power, and eco-friendly architecture.
                                </p>
                            </div>
                        </div>
                    </div>

                    <!-- Student Life -->
                    <div class="col-md-4 mb-4">
                        <div class="card border-0 shadow h-100 p-4">
                            <div class="card-body">
                                <h3 class="card-title fw-semibold text-success">Student Life</h3>
                                <p style="font-size: 13px;" class="fs-5 text-muted">
                                    Vibrant community spaces that foster collaboration, creativity, and personal growth.
                                </p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>
</div>

<!-- CAMPUS LIFE – GLASSMORPHISM SECTION -->
<section class="py-5" style="
    background: url('assets/uploads/campus-bg.jpeg') center/cover no-repeat;
    position: relative;">

    <!-- Dark overlay -->
    <div style="position:absolute; inset:0; background:rgba(0,0,0,0.45);"></div>

    <div class="container position-relative" style="z-index:2;">

        <!-- Title -->
        <div class="text-center text-white mb-5">
            <h2 class="fw-bold text-white" style="font-size:2.5rem;">Welcome to Campus Living</h2>
            <p class="w-75 mx-auto text-white" style="font-size:1.15rem; opacity:0.9;">
                A lively, inclusive, and engaging environment for every student. Explore a vibrant and inspiring campus filled with creativity, sports, culture, and world-class facilities.
            </p>
        </div>

        <div class="row g-4">

            <!-- Card 1 -->
            <div class="col-md-4">
                <a href="club.php" style="text-decoration:none;">
                    <div style="
                        backdrop-filter: blur(14px);
                        background: rgba(255,255,255,0.15);
                        border-radius: 18px;
                        padding: 25px;
                        color: white;
                        border: 1px solid rgba(255,255,255,0.3);
                        box-shadow: 0 8px 20px rgba(0,0,0,0.35);
                        height:100%;
                        transition: transform 0.35s ease, box-shadow 0.35s ease;
                    ">
                        <div style="
                            width:65px;
                            height:65px;
                            background:#00a651;
                            border-radius:12px;
                            display:flex;
                            justify-content:center;
                            align-items:center;
                            font-size:30px;
                            margin-bottom:15px;
                        ">🎭</div>

                        <h5 class="fw-bold text-white">Clubs & Activities</h5>
                        <p class="mb-0 text-white" style="opacity:0.9;">
                            Numerous student clubs foster creativity, leadership, and cultural expression.
                        </p>
                    </div>
                </a>
            </div>

            <!-- Card 2 -->
            <div class="col-md-4">
                <a href="sports.php" style="text-decoration:none;">
                    <div style="
                        backdrop-filter: blur(14px);
                        background: rgba(255,255,255,0.15);
                        border-radius: 18px;
                        padding: 25px;
                        color: white;
                        border: 1px solid rgba(255,255,255,0.3);
                        box-shadow: 0 8px 20px rgba(0,0,0,0.35);
                        height:100%;
                        transition: transform 0.35s ease, box-shadow 0.35s ease;
                    ">
                        <div style="
                            width:65px;
                            height:65px;
                            background:#00a651;
                            border-radius:12px;
                            display:flex;
                            justify-content:center;
                            align-items:center;
                            font-size:30px;
                            margin-bottom:15px;
                        ">⚽</div>

                        <h5 class="fw-bold text-white">Sports & Fitness</h5>
                        <p class="mb-0 text-white" style="opacity:0.9;">
                            Top-tier sports facilities, tournaments, and a fitness culture that keeps students active.
                        </p>
                    </div>
                </a>
            </div>

            <!-- Card 3 -->
            <div class="col-md-4">
                <a href="campus-life.php" style="text-decoration:none;">
                    <div style="
                        backdrop-filter: blur(14px);
                        background: rgba(255,255,255,0.15);
                        border-radius: 18px;
                        padding: 25px;
                        color: white;
                        border: 1px solid rgba(255,255,255,0.3);
                        box-shadow: 0 8px 20px rgba(0,0,0,0.35);
                        height:100%;
                        transition: transform 0.35s ease, box-shadow 0.35s ease;
                    ">
                        <div style="
                            width:65px;
                            height:65px;
                            background:#00a651;
                            border-radius:12px;
                            display:flex;
                            justify-content:center;
                            align-items:center;
                            font-size:30px;
                            margin-bottom:15px;
                        ">🏫</div>

                        <h5 class="fw-bold text-white">Modern Facilities</h5>
                        <p class="mb-0 text-white" style="opacity:0.9;">
                            Advanced labs, digital library, smart classrooms, and collaborative learning spaces.
                        </p>
                    </div>
                </a>
            </div>

        </div>
        <section class="campus-gallery-section">

            <!-- ===== INLINE STYLES (SELF-CONTAINED) ===== -->
            <style>
                .campus-gallery-container {
                    max-width: 1200px;
                    margin: 0 auto;
                }

                /* Header */
                .campus-gallery-header {
                    max-width: 1200px;
                    margin-bottom: 60px;
                }

                .campus-gallery-header h2 {
                    font-size: 38px;
                    font-weight: 800;
                    margin-bottom: 12px;
                    color: #111;
                }

                .campus-gallery-header p {
                    font-size: 17px;
                    line-height: 1.7;
                    color: #555;
                }

                /* Grid */
                .campus-gallery-grid {
                    display: grid;
                    grid-template-columns: repeat(4, 1fr);
                    grid-auto-rows: 260px;
                    gap: 20px;
                }

                /* Items */
                .gallery-item {
                    position: relative;
                    overflow: hidden;
                    border-radius: 16px;
                    cursor: pointer;
                    animation: fadeUp 0.9s ease both;
                }

                .gallery-item img {
                    width: 100%;
                    height: 100%;
                    object-fit: cover;
                    transition: transform 0.6s ease;
                }

                /* Overlay */
                .gallery-overlay {
                    position: absolute;
                    inset: 0;
                    background: linear-gradient(to top,
                            rgba(0, 0, 0, 0.65),
                            rgba(0, 0, 0, 0.15));
                    display: flex;
                    align-items: flex-end;
                    padding: 18px;
                    opacity: 0;
                    transition: opacity 0.4s ease;
                }

                .gallery-overlay span {
                    color: #fff;
                    font-weight: 600;
                    letter-spacing: 0.3px;
                    font-size: 15px;
                }

                /* Hover */
                .gallery-item:hover img {
                    transform: scale(1.08);
                }

                .gallery-item:hover .gallery-overlay {
                    opacity: 1;
                }

                /* Featured */
                .gallery-item.featured {
                    grid-column: span 2;
                    grid-row: span 2;
                }

                /* Animation */
                @keyframes fadeUp {
                    from {
                        opacity: 0;
                        transform: translateY(30px);
                    }

                    to {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }

                /* Responsive */
                @media (max-width: 992px) {
                    .campus-gallery-grid {
                        grid-template-columns: repeat(2, 1fr);
                        grid-auto-rows: 220px;
                    }

                    .gallery-item.featured {
                        grid-column: span 2;
                        grid-row: span 1;
                    }
                }

                @media (max-width: 576px) {
                    .campus-gallery-grid {
                        grid-template-columns: 1fr;
                        grid-auto-rows: 220px;
                    }

                    .gallery-item.featured {
                        grid-column: span 1;
                    }
                }
            </style>


            <!-- ===== CONTENT ===== -->
            <div class="campus-gallery-container">

                <div class="campus-gallery-header text-center mt-3">
                    <h2 class="text-white">Campus Gallery</h2>
                    <p class="text-white">
                        A collection of moments that reflect learning, creativity, collaboration,
                        and everyday life within the Maya Devi University campus.
                    </p>

                </div>

                <div class="campus-gallery-grid">

                    <!-- Featured Image -->
                    <div class="gallery-item featured">
                        <img src="assets/uploads/campus-9.jpeg" alt="Campus Life">
                        <div class="gallery-overlay">
                            <span>Campus Life</span>
                        </div>
                    </div>

                    <div class="gallery-item">
                        <img src="assets/uploads/ai.jpeg" alt="Student Activities">
                        <div class="gallery-overlay"><span>Advance AI Labs</span></div>
                    </div>

                    <div class="gallery-item">
                        <img src="assets/uploads/library-2.jpeg" alt="Library">
                        <div class="gallery-overlay"><span>Central Library</span></div>
                    </div>

                    <div class="gallery-item">
                        <img src="assets/uploads/robots.jpeg" alt="Laboratories">
                        <div class="gallery-overlay"><span>Advanced Laboratories</span></div>
                    </div>

                    <div class="gallery-item">
                        <img src="assets/uploads/hostel.jpg" alt="Hostel Life">
                        <div class="gallery-overlay"><span>Hostel Life</span></div>
                    </div>

                </div>

            </div>

        </section>
        <!-- Button -->
        <div class="text-center mt-5">
            <a href="campus-life.php" class="btn btn-lg px-4"
                style="background:#00a651; color:white; border-radius:50px; font-weight:600;">
                Explore More →
            </a>
        </div>

    </div>
</section>



<section class="mdu-facility-immersive">

    <!-- RIGHT IMAGE COLUMN -->
    <div class="mdu-facility-images">
        <div class="fi-img active" style="background-image:url('assets/uploads/computer.webp')"></div>
        <div class="fi-img" style="background-image:url('assets/uploads/library.png')"></div>
        <div class="fi-img" style="background-image:url('assets/uploads/social.webp')"></div>
        <div class="fi-img" style="background-image:url('assets/uploads/auditorium.jpg')"></div>
        <div class="fi-img" style="background-image:url('assets/uploads/hostel.jpg')"></div>
        <div class="fi-img" style="background-image:url('assets/uploads/transport.webp')"></div>
    </div>

    <!-- LEFT FACILITY TEXT -->
    <div class="mdu-facility-content">
        <h2 class="fc-title">
            Modern <span>Facilities</span> That<br> Empower Every Student
        </h2>

        <div class="fc-list">

            <div class="fc-item" data-index="0">
                <h3>Advanced Computer & Technology Labs</h3>
                <p>Well-equipped labs supporting programming, AI, machine learning, analytics, robotics, and digital innovation.</p>
            </div>

            <div class="fc-item" data-index="1">
                <h3>Central Library & E-Resource Hub</h3>
                <p>Access to books, journals, research papers, digital learning platforms, and study areas to assist academic and competitive exam preparation.</p>
            </div>

            <div class="fc-item" data-index="2">
                <h3>Health & Wellness Centre</h3>
                <p>On-campus medical support with tie-ups for emergency care and routine health checkups.</p>
            </div>

            <div class="fc-item" data-index="3">
                <h3>Multi-Functional Auditorium & Seminar Halls</h3>
                <p>Designed for conferences, workshops, cultural programs, and guest lectures.</p>
            </div>

            <div class="fc-item" data-index="4">
                <h3>Secure & Comfortable Hostels</h3>
                <p>Separate hostels for boys and girls with modern amenities, 24x7 security, study spaces, and recreational zones.</p>
            </div>

            <div class="fc-item" data-index="5">
                <h3>Transport Facilities</h3>
                <p>University-managed buses connecting major areas in Dehradun, ensuring safe and convenient travel.</p>
            </div>

        </div>
    </div>

</section>

<style>
    :root {
        --mdu-green: #00a651;
    }

    /* MAIN WRAPPER */
    .mdu-facility-immersive {
        display: flex;
        max-width: 1350px;
        margin: 60px auto;
        padding: 0 20px;
        gap: 40px;
        font-family: "Poppins", sans-serif;
        position: relative;
    }

    /* LEFT CONTENT */
    .mdu-facility-content {
        flex: 0 0 45%;
    }

    .fc-title {
        font-size: 34px;
        font-weight: 800;
        margin-bottom: 32px;
        line-height: 1.25;
    }

    .fc-title span {
        color: var(--mdu-green);
        font-style: italic;
    }

    /* FACILITY LIST */
    .fc-list {
        display: flex;
        flex-direction: column;
        gap: 38px;
    }

    .fc-item {
        padding: 6px 0;
        border-left: 3px solid transparent;
        padding-left: 18px;
        opacity: .45;
        transform: translateY(20px);
        transition: .35s;
        cursor: pointer;
    }

    .fc-item h3 {
        margin: 0 0 6px;
        font-size: 22px;
        font-weight: 700;
    }

    .fc-item p {
        margin: 0;
        color: #333;
        line-height: 1.45;
    }

    /* ACTIVE STATE */
    .fc-item.active {
        opacity: 1;
        border-color: var(--mdu-green);
        transform: translateY(0);
    }

    /* RIGHT IMAGE COLUMN */
    .mdu-facility-images {
        flex: 1;
        position: sticky;
        top: 120px;
        height: 540px;
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 18px 40px rgba(0, 0, 0, 0.10);
    }

    .fi-img {
        position: absolute;
        inset: 0;
        background-size: cover;
        background-position: center;
        opacity: 0;
        transform: scale(1.05);
        transition: opacity .6s ease, transform .6s ease;
    }

    .fi-img.active {
        opacity: 1;
        transform: scale(1);
    }

    /* RESPONSIVE */
    @media (max-width: 900px) {

        /* Disable desktop image column */
        .mdu-facility-images {
            display: none;
        }

        .mdu-facility-content {
            flex: 0 0 100%;
        }

        /* Mobile images inserted after headings */
        .mobile-fi-img {
            width: 100%;
            height: 220px;
            margin: 14px 0 28px;
            border-radius: 12px;
            background-size: cover;
            background-position: center;
            box-shadow: 0 14px 30px rgba(0, 0, 0, .12);
        }

        /* No faded items on mobile */
        .fc-item {
            opacity: 1;
            transform: none;
            cursor: default;
        }
    }
</style>
<script>
    (function() {

        let currentMode = null;

        function initFacilities() {
            const items = document.querySelectorAll(".fc-item");
            const imgs = document.querySelectorAll(".fi-img");

            if (!items.length || !imgs.length) return;

            const isMobile = window.innerWidth <= 900;
            const newMode = isMobile ? "mobile" : "desktop";

            // prevent unnecessary re-init
            if (currentMode === newMode) return;
            currentMode = newMode;

            /* ========= RESET ========= */
            items.forEach(i => i.classList.remove("active"));
            imgs.forEach(i => i.classList.remove("active"));
            document.querySelectorAll(".mobile-fi-img").forEach(img => img.remove());

            items.forEach(item => {
                item.onmouseenter = null;
                item.onclick = null;
            });

            /* ========= MOBILE ========= */
            if (isMobile) {
                items.forEach((item, index) => {
                    if (!imgs[index]) return;

                    const imgDiv = document.createElement("div");
                    imgDiv.className = "mobile-fi-img";
                    imgDiv.style.backgroundImage = imgs[index].style.backgroundImage;
                    item.insertAdjacentElement("afterend", imgDiv);
                });
                return;
            }

            /* ========= DESKTOP (HOVER) ========= */
            items[0].classList.add("active");
            imgs[0].classList.add("active");

            items.forEach(item => {
                item.onmouseenter = () => {
                    const index = item.dataset.index;

                    items.forEach(i => i.classList.remove("active"));
                    imgs.forEach(i => i.classList.remove("active"));

                    item.classList.add("active");
                    imgs[index]?.classList.add("active");
                };
            });
        }

        // init on load
        window.addEventListener("load", initFacilities);

        // re-init when crossing breakpoint
        window.addEventListener("resize", () => {
            clearTimeout(window.__mduResizeTimer);
            window.__mduResizeTimer = setTimeout(initFacilities, 150);
        });

    })();
</script>


<div class="container mb-4">
    <div class="row align-items-center">
        <!-- Left Side - Image -->
        <div class="col-lg-6 text-center">
            <img src="assets/uploads/campus-2.jpeg" alt="Logo" class="img-fluid rounded-lg shadow-sm p-2 bg-light" style="max-height: 500px;">
        </div>

        <!-- Right Side - Text -->
        <div class="col-lg-6">
            <h1 class="fw-bold text-success mb-3">
                Experience Excellence at the Best University in Dehradun – Maya Devi University
            </h1>
            <p class="fs-5 text-muted">
                At <strong>Maya Devi University</strong>, recognized as the best university in Dehradun,
                we offer a transformative learning experience that goes beyond traditional education.
                Our innovative approach is built around the <strong>8 Abilities</strong> – a comprehensive framework
                designed to develop well-rounded, future-ready individuals equipped with the skills
                to excel in their careers and make a lasting impact in the world.
            </p>
            <a href="campus-life.php" class="btn btn-success btn-lg mt-3">Learn More</a>
        </div>
    </div>
</div>
<!-- Stats Section -->
<!-- ========== MDU TIMELINE WITH RIGHT IMAGE (FULL BLOCK) ========== -->
<!-- ========================================================= -->
<!-- ============= MDU LEGACY TIMELINE (NON-CONFLICT) ======== -->
<!-- ========================================================= -->

<section class="mduLegacy-wrap">
    <div class="mduLegacy-layout">

        <!-- LEFT Timeline -->
        <section class="mduLegacy-timeline" aria-labelledby="mduLegacy-title">
            <div class="mduLegacy-inner">

                <h2 id="mduLegacy-title" class="mduLegacy-heading">
                    An <span>Illustrious</span> Legacy We <strong>Shape</strong>
                </h2>

                <div class="mduLegacy-track">

                    <article class="mduLegacy-item" data-target="120">
                        <div class="mduLegacy-bubble">120+</div>
                        <div class="mduLegacy-card">
                            <div class="mduLegacy-card-head">Programs</div>
                            <p class="mduLegacy-card-desc">
                                Industry-oriented undergraduate & postgraduate programs focused on employability.
                            </p>
                        </div>
                    </article>

                    <article class="mduLegacy-item" data-target="100">
                        <div class="mduLegacy-bubble">100+</div>
                        <div class="mduLegacy-card">
                            <div class="mduLegacy-card-head">Stalwarts</div>
                            <p class="mduLegacy-card-desc">
                                Industry stalwarts and mentors collaborating with students & faculty.
                            </p>
                        </div>
                    </article>

                    <article class="mduLegacy-item" data-target="35">
                        <div class="mduLegacy-bubble">35+</div>
                        <div class="mduLegacy-card">
                            <div class="mduLegacy-card-head">Doctoral Faculty</div>
                            <p class="mduLegacy-card-desc">
                                Research-active doctoral faculty guiding projects & publications.
                            </p>
                        </div>
                    </article>

                    <article class="mduLegacy-item" data-target="12000">
                        <div class="mduLegacy-bubble">12000+</div>
                        <div class="mduLegacy-card">
                            <div class="mduLegacy-card-head">Alumni</div>
                            <p class="mduLegacy-card-desc">
                                A strong alumni network across industries and geographies.
                            </p>
                        </div>
                    </article>

                </div>
            </div>
        </section>

        <!-- RIGHT: Image -->
        <div class="mduLegacy-image">
            <img src="assets/uploads/girl-3.jpeg" alt="Campus Image" loading="lazy">
        </div>

    </div>
</section>
<!-- ======================= CSS ============================= -->
<style>
    :root {
        --mduLegacy-green: #00a651;
    }

    /* Wrapper */
    .mduLegacy-wrap {
        background: #fff;
        padding: 40px 20px;
        font-family: "Poppins", Arial, sans-serif;
    }

    /* 2-Column Layout */
    .mduLegacy-layout {
        max-width: 1300px;
        margin: auto;
        display: grid;
        grid-template-columns: 1fr 430px;
        gap: 40px;
        align-items: stretch;
    }

    /* Right Image */
    .mduLegacy-image {
        width: 100%;
        height: 100%;
        border-radius: 16px;
        overflow: hidden;
        box-shadow: 0 20px 45px rgba(0, 0, 0, 0.12);
    }

    .mduLegacy-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    /* Timeline Content */
    .mduLegacy-heading {
        font-size: 30px;
        font-weight: 800;
        margin-bottom: 28px;
        color: #111;
        line-height: 1.2;
    }

    .mduLegacy-heading span {
        color: var(--mduLegacy-green);
        font-style: italic;
    }

    /* Track */
    .mduLegacy-track {
        position: relative;
        display: grid;
        gap: 34px;
        padding: 0 36px;
    }

    /* Vertical Line */
    .mduLegacy-track::before {
        content: "";
        position: absolute;
        left: calc(50% - 1px);
        top: 0;
        bottom: 0;
        width: 2px;
        background: rgba(0, 0, 0, 0.06);
        z-index: 0;
    }

    /* Items */
    .mduLegacy-item {
        display: flex;
        gap: 18px;
        opacity: 0;
        transform: translateY(40px);
        transition: all 0.7s ease-out;
        z-index: 2;
    }

    .mduLegacy-item.inview {
        opacity: 1;
        transform: translateY(0);
    }

    /* Odd/Even Position */
    .mduLegacy-item:nth-child(odd) {
        justify-content: flex-start;
    }

    .mduLegacy-item:nth-child(even) {
        flex-direction: row-reverse;
    }

    /* Bubble */
    .mduLegacy-bubble {
        width: 110px;
        height: 110px;
        background: linear-gradient(160deg, var(--mduLegacy-green), #028a47);
        border-radius: 18px;
        font-size: 28px;
        font-weight: 900;
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    /* Card */
    .mduLegacy-card {
        background: #fff;
        padding: 16px 18px;
        border-radius: 12px;
        border: 1px solid #0056b3;
        box-shadow: 0 10px 30px rgba(2, 6, 23, 0.08);
        max-width: 520px;
    }

    .mduLegacy-card-head {
        font-size: 18px;
        font-weight: 800;
        margin-bottom: 6px;
        color: #0b2b2b;
    }

    .mduLegacy-card-desc {
        font-size: 14px;
        color: #3b4a4a;
        line-height: 1.45;
    }

    /* Mobile Responsive */
    @media (max-width: 992px) {
        .mduLegacy-layout {
            grid-template-columns: 1fr;
        }

        .mduLegacy-image {
            height: 330px;
            margin-top: 20px;
        }
    }

    @media (max-width: 600px) {
        .mduLegacy-image {
            height: 240px;
        }

        .mduLegacy-track::before {
            left: 20px;
        }

        .mduLegacy-item,
        .mduLegacy-item:nth-child(even) {
            flex-direction: row;
        }

        .mduLegacy-card {
            max-width: calc(100% - 120px);
        }
    }
</style>
<script>
    (function() {
        const items = document.querySelectorAll('.mduLegacy-item');

        const io = new IntersectionObserver((entries, obs) => {
            entries.forEach(entry => {
                if (!entry.isIntersecting) return;

                const el = entry.target;
                el.classList.add('inview');

                const bubble = el.querySelector('.mduLegacy-bubble');
                const target = parseInt(el.getAttribute("data-target")) || 0;

                // If number is too large, skip animation
                if (target >= 5000) {
                    bubble.textContent = target + "+";
                    obs.unobserve(el);
                    return;
                }

                bubble.textContent = "0";


                let start = 0;
                const duration = 1200;
                const step = Math.max(Math.floor(duration / target), 10);

                const timer = setInterval(() => {
                    start++;
                    bubble.textContent = start + "+";
                    if (start >= target) clearInterval(timer);
                }, step);

                obs.unobserve(el);
            });
        }, {
            threshold: 0.3
        });

        items.forEach(i => io.observe(i));
    })();
</script>
<!-- Include AOS Animation CSS & JS -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>

<section class="rankings-section">
    <div class="section-title-3 section-shape-hm2-1 text-center mb-5">
        <h2 style="font-size: 40px; color: green; font-weight: bold;">Rankings & Accreditations</h2>

        <div class="rankings-container">
            <!-- Card 1 -->
            <div class="ranking-card" data-aos="fade-up" data-aos-duration="1000">
                <img src="assets/uploads/icon/rank-1.webp" alt="WURI">
            </div>

            <!-- Card 2 -->
            <div class="ranking-card" data-aos="fade-up" data-aos-duration="1200">
                <img src="assets/uploads/icon/rank-2.png" alt="THE Rankings">
            </div>

            <!-- Card 3 -->
            <div class="ranking-card" data-aos="fade-up" data-aos-duration="1400">
                <img src="assets/uploads/icon/rank-3.png" alt="NIRF">
            </div>

            <!-- Card 4 -->
            <div class="ranking-card" data-aos="fade-up" data-aos-duration="1600">
                <img src="assets/uploads/icon/rank-4.webp" alt="THE Impact Rankings">
            </div>

            <!-- Card 5 -->
            <div class="ranking-card" data-aos="fade-up" data-aos-duration="1800">
                <img src="assets/uploads/icon/rank-5.png" alt="Other Ranking">
            </div>
        </div>
    </div>
</section>

<script>
    AOS.init();
</script>

<style>
    .rankings-container {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        max-width: 1200px;
        margin: auto;
    }

    .ranking-card {
        border: 1px solid #ddd;
        background: #fff;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        height: 150px;
        /* keep height consistent */
    }

    .ranking-card img {
        max-height: 120px;
        max-width: 100%;
        object-fit: contain;
    }

    .ranking-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 6px 15px rgba(0, 0, 0, 0.15);
    }
</style>
<div class="course-area bg-img pt-70 pb-10" style="background-image:url(assets/uploads/bg-1.webp);">
    <div class="container">
        <div class="section-title mb-55">
            <h2> <span>Diploma</span> Courses</h2>
            <p>Our Diploma programs emphasize practical training and industry relevance, <br>empowering students with job-ready skills and career opportunities.</p>
        </div>
        <div class="course-slider-active nav-style-1 owl-carousel">
            <div class="single-course">
                <div class="course-img">
                    <a href="best-d-pharma-college-in-dehradun-uttarakhand.php"><img class="animated" src="assets/uploads/d.pharmacy.jpeg" alt="Course image"></a>
                </div>
                <div class="course-content">
                    <h4><a href="best-d-pharma-college-in-dehradun-uttarakhand.php">Diploma in Pharmacy</a></h4>
                    <p>The Diploma in Pharmacy program trains students in pharmaceutical sciences, drug formulation, and practical pharmacy skills.</p>
                </div>
                <div class="course-position-content">
                    <div class="credit-duration-wrap">
                        <div class="sin-credit-duration">
                            <i class="fa fa-diamond"></i>
                            <span>Credits : 125</span>
                        </div>
                        <div class="sin-credit-duration">
                            <i class="fa fa-clock-o"></i>
                            <span>Duration : 2yrs</span>
                        </div>
                    </div>
                    <div class="course-btn">
                        <a class="default-btn" href="best-d-pharma-college-in-dehradun-uttarakhand.php">APPLY NOW</a>
                    </div>
                </div>
            </div>
            <div class="single-course">
                <div class="course-img">
                    <a href="diploma-in-confectionary.php"><img class="animated" src="assets/uploads/bakery.webp" alt="Course image"></a>
                </div>
                <div class="course-content">
                    <h4><a href="diploma-in-confectionary.php">Diploma in Bakery & Confectionary</a></h4>
                    <p>The Diploma in Bakery and Confectionery program is a two-year course focusing on baking techniques, pastry arts, confectionery production, and dessert presentation.</p>
                </div>
                <div class="course-position-content">
                    <div class="credit-duration-wrap">
                        <div class="sin-credit-duration">
                            <i class="fa fa-diamond"></i>
                            <span>Credits : 125</span>
                        </div>
                        <div class="sin-credit-duration">
                            <i class="fa fa-clock-o"></i>
                            <span>Duration : 2yrs</span>
                        </div>
                    </div>
                    <div class="course-btn">
                        <a class="default-btn" href="diploma-in-confectionary.php">APPLY NOW</a>
                    </div>
                </div>
            </div>
            <div class="single-course">
                <div class="course-img">
                    <a href="diploma-in-food-production.php"><img class="animated" src="assets/uploads/dhm.webp" alt="Course image"></a>
                </div>
                <div class="course-content">
                    <h4><a href="diploma-in-food-production.php">Diploma in Food Production</a></h4>
                    <p>The Diploma in Food Production is a two-year program focusing on culinary techniques, kitchen operations, food preparation, and professional cookery standards.</p>
                </div>
                <div class="course-position-content">
                    <div class="credit-duration-wrap">
                        <div class="sin-credit-duration">
                            <i class="fa fa-diamond"></i>
                            <span>Credits : 125</span>
                        </div>
                        <div class="sin-credit-duration">
                            <i class="fa fa-clock-o"></i>
                            <span>Duration : 2yrs</span>
                        </div>
                    </div>
                    <div class="course-btn">
                        <a class="default-btn" href="diploma-in-food-production.php">APPLY NOW</a>
                    </div>
                </div>
            </div>
            <div class="single-course">
                <div class="course-img">
                    <a href="gnm.php"><img class="animated" src="assets/uploads/gnm.webp" alt="Course image"></a>
                </div>
                <div class="course-content">
                    <h4><a href="gnm.php">General Nursing and Midwifery (GNM)</a></h4>
                    <p>The GNM program is a diploma course for training students in professional nursing and care.</p>
                </div>
                <div class="course-position-content">
                    <div class="credit-duration-wrap">
                        <div class="sin-credit-duration">
                            <i class="fa fa-diamond"></i>
                            <span>Credits : 125</span>
                        </div>
                        <div class="sin-credit-duration">
                            <i class="fa fa-clock-o"></i>
                            <span>Duration : 3yrs</span>
                        </div>
                    </div>
                    <div class="course-btn">
                        <a class="default-btn" href="gnm.php">APPLY NOW</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="section-title mb-55">
            <h2> <span>UG</span> Courses</h2>
            <p>Our UG programs blend academic depth with real-world exposure, <br>equipping students with strong foundations and skills for lifelong success.</p>
        </div>

        <div class="course-slider-active nav-style-1 owl-carousel">
            <div class="single-course">
                <div class="course-img">
                    <a href="b.tech-AI-ML.php"><img class="animated" src="assets/uploads/ai.jpeg" alt="Course image"></a>

                </div>
                <div class="course-content">
                    <h4><a href="b.tech-AI-ML.php">B.tech With Specialization in AI & ML</a></h4>
                    <p>Focused program in AI and Machine Learning, covering neural networks and intelligent systems.</p>
                </div>
                <div class="course-position-content">
                    <div class="credit-duration-wrap">
                        <div class="sin-credit-duration">
                            <i class="fa fa-diamond"></i>
                            <span>Credits : 125</span>
                        </div>
                        <div class="sin-credit-duration">
                            <i class="fa fa-clock-o"></i>
                            <span>Duration : 4yrs</span>
                        </div>
                    </div>
                    <div class="course-btn">
                        <a class="default-btn" href="b.tech-AI-ML.php">APPLY NOW</a>
                    </div>
                </div>
            </div>
            <div class="single-course">
                <div class="course-img">
                    <a href="b.tech-cyber_security.php"><img class="animated" src="assets/uploads/cyber-security.webp" alt="Course image"></a>
                </div>
                <div class="course-content">
                    <h4><a href="b.tech-cyber_security.php">B.tech With Specialization in Cyber Security</a></h4>
                    <p>Specialized program in cyber security and digital forensics with IBM, focusing on threat detection and mitigation.</p>
                </div>
                <div class="course-position-content">
                    <div class="credit-duration-wrap">
                        <div class="sin-credit-duration">
                            <i class="fa fa-diamond"></i>
                            <span>Credits : 125</span>
                        </div>
                        <div class="sin-credit-duration">
                            <i class="fa fa-clock-o"></i>
                            <span>Duration : 4yrs</span>
                        </div>
                    </div>
                    <div class="course-btn">
                        <a class="default-btn" href="b.tech-cyber_security.php">APPLY NOW</a>
                    </div>
                </div>
            </div>
            <div class="single-course">
                <div class="course-img">
                    <a href="b.tech-CSE.php"><img class="animated" src="assets/uploads/computer.webp" alt="Course image"></a>
                </div>
                <div class="course-content">
                    <h4><a href="b.tech-CSE.php">B.Tech. Computer Science & Engineering</a></h4>
                    <p>Core program in computer science, covering programming, algorithms, and system design.</p>
                </div>
                <div class="course-position-content">
                    <div class="credit-duration-wrap">
                        <div class="sin-credit-duration">
                            <i class="fa fa-diamond"></i>
                            <span>Credits : 125</span>
                        </div>
                        <div class="sin-credit-duration">
                            <i class="fa fa-clock-o"></i>
                            <span>Duration : 4yrs</span>
                        </div>
                    </div>
                    <div class="course-btn">
                        <a class="default-btn" href="b.tech-CSE.php">APPLY NOW</a>
                    </div>
                </div>
            </div>
            <div class="single-course">
                <div class="course-img">
                    <a href="b.tech-data_science.php"><img class="animated" src="assets/uploads/data-science.webp" alt="Course image"></a>

                </div>
                <div class="course-content">
                    <h4><a href="b.tech-data_science.php">B.tech With Specialization in Data Science</a></h4>
                    <p>Focused program on data science with IBM, covering data analysis, visualization, and predictive modeling.</p>
                </div>
                <div class="course-position-content">
                    <div class="credit-duration-wrap">
                        <div class="sin-credit-duration">
                            <i class="fa fa-diamond"></i>
                            <span>Credits : 125</span>
                        </div>
                        <div class="sin-credit-duration">
                            <i class="fa fa-clock-o"></i>
                            <span>Duration : 4yrs</span>
                        </div>
                    </div>
                    <div class="course-btn">
                        <a class="default-btn" href="b.tech-data_science.php">APPLY NOW</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="section-title mb-55">
            <h2> <span>PG</span> Courses</h2>
            <p>Our PG programs foster advanced expertise and research-driven learning,<br> preparing graduates for leadership roles and specialized career growth.</p>
        </div>
        <div class="course-slider-active nav-style-1 owl-carousel">
            <div class="single-course">
                <div class="course-img">
                    <a href="m.tech-structural-engineering.php"><img class="animated" src="assets/uploads/b.tech-civil.jpg" alt="Course image"></a>
                </div>
                <div class="course-content">
                    <h4><a href="m.tech-mechanical-engineering.php">M.Tech in Structural Engineering</a></h4>
                    <p>The M.Tech Structural Engineering is a two-year program focusing on advanced structural design, analysis, and construction technologies.</p>
                </div>
                <div class="course-position-content">
                    <div class="credit-duration-wrap">
                        <div class="sin-credit-duration">
                            <i class="fa fa-diamond"></i>
                            <span>Credits : 125</span>
                        </div>
                        <div class="sin-credit-duration">
                            <i class="fa fa-clock-o"></i>
                            <span>Duration : 2yrs</span>
                        </div>
                    </div>
                    <div class="course-btn">
                        <a class="default-btn" href="m.tech-mechanical-engineering.php">APPLY NOW</a>
                    </div>
                </div>
            </div>
            <div class="single-course">
                <div class="course-img">
                    <a href="m.tech-mechanical-engineering.php"><img class="animated" src="assets/uploads/mtech-mechanical.webp" alt="Course image"></a>
                </div>
                <div class="course-content">
                    <h4><a href="m.tech-mechanical-engineering.php">M.Tech in Mechanical Engineering</a></h4>
                    <p>Mechanical Engineering is one of the major streams in the engineering profession and its principles are involved in the design, study, development and construction of nearly all of the physical devices and systems.</p>
                </div>
                <div class="course-position-content">
                    <div class="credit-duration-wrap">
                        <div class="sin-credit-duration">
                            <i class="fa fa-diamond"></i>
                            <span>Credits : 125</span>
                        </div>
                        <div class="sin-credit-duration">
                            <i class="fa fa-clock-o"></i>
                            <span>Duration : 2yrs</span>
                        </div>
                    </div>
                    <div class="course-btn">
                        <a class="default-btn" href="m.tech-mechanical-engineering.php">APPLY NOW</a>
                    </div>
                </div>
            </div>
            <div class="single-course">
                <div class="course-img">
                    <a href="master-in-agriculture.php"><img class="animated" src="assets/uploads/agriculture.webp" alt="Course image"></a>
                </div>
                <div class="course-content">
                    <h4><a href="master-in-agriculture.php">Master in agriculture</a></h4>
                    <p>The Master in Agriculture program offers advanced training in crop production, soil management, and sustainable farming, preparing graduates for research and leadership roles in agriculture.</p>
                </div>
                <div class="course-position-content">
                    <div class="credit-duration-wrap">
                        <div class="sin-credit-duration">
                            <i class="fa fa-diamond"></i>
                            <span>Credits : 125</span>
                        </div>
                        <div class="sin-credit-duration">
                            <i class="fa fa-clock-o"></i>
                            <span>Duration : 2yrs</span>
                        </div>
                    </div>
                    <div class="course-btn">
                        <a class="default-btn" href="master-in-agriculture.php">APPLY NOW</a>
                    </div>
                </div>
            </div>
            <div class="single-course">
                <div class="course-img">
                    <a href="genetics-and-plant-breeding.php"><img class="animated" src="assets/uploads/genetics.webp" alt="Course image"></a>
                </div>
                <div class="course-content">
                    <h4><a href="genetics-and-plant-breeding.php">M.Sc. in Genetics and Plant Breeding</a></h4>
                    <p>The M.Sc. in Genetics and Plant Breeding program focuses on advanced plant genetics, crop improvement, and research skills for modern agriculture.</p>
                </div>
                <div class="course-position-content">
                    <div class="credit-duration-wrap">
                        <div class="sin-credit-duration">
                            <i class="fa fa-diamond"></i>
                            <span>Credits : 125</span>
                        </div>
                        <div class="sin-credit-duration">
                            <i class="fa fa-clock-o"></i>
                            <span>Duration : 2yrs</span>
                        </div>
                    </div>
                    <div class="course-btn">
                        <a class="default-btn" href="genetics-and-plant-breeding.php">APPLY NOW</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="course-button">
            <a href="course.php" class="button-link">View More Courses</a>
        </div>
    </div>
</div>
<style>
    .course-button {
        margin: 10px auto;
        text-align: center;
    }

    a.button-link {
        padding: 12px 24px;
        font-size: 16px;
        background-color: #00a651;
        color: white;
        border-radius: 6px;
        text-decoration: none;
        display: inline-block;
    }

    a.button-link:hover {
        background-color: #0056b3;
    }
</style>
<section class="mdu-section">
    <div class="container">

        <!-- Header -->
        <div class="row align-items-center mb-5">
            <div class="col-lg-6">
                <h1 class="mdu-title">
                    Best University in Dehradun
                    <span>Why Maya Devi University Stands Out?</span>
                </h1>

                <p>
                    At Maya Devi University, Dehradun, we deliver world-class education
                    through experienced faculty, modern infrastructure, and global exposure.
                    Our focus on academic excellence and holistic development empowers students
                    to thrive in their careers and contribute positively to society.
                </p>

                <p>
                    Discover a transformative educational journey with industry-aligned programs,
                    global collaborations, and career-focused learning.
                </p>

                <a href="https://admissions.maya.edu.in" class="mdu-btn">
                    Apply Now
                </a>
            </div>

            <!-- Feature Cards -->
            <div class="col-lg-6">
                <div class="feature-grid">

                    <div class="feature-card">
                        <img src="assets/uploads/world-edu.png" alt="Education">
                        <h4>World-Class Education</h4>
                        <p>Cutting-edge curriculum aligned with global standards.</p>
                    </div>

                    <div class="feature-card">
                        <img src="assets/uploads/e-faculty.jpg" alt="Faculty">
                        <h4>Expert Faculty</h4>
                        <p>Learn from experienced academicians and professionals.</p>
                    </div>

                    <div class="feature-card">
                        <img src="assets/uploads/m-infra.png" alt="Infrastructure">
                        <h4>Modern Infrastructure</h4>
                        <p>Advanced labs, smart classrooms, and research centers.</p>
                    </div>

                    <div class="feature-card">
                        <img src="assets/uploads/global.png" alt="Opportunities">
                        <h4>Global Opportunities</h4>
                        <p>International exposure, internships & collaborations.</p>
                    </div>

                </div>
            </div>
        </div>

        <!-- Hexagonal Gallery -->
        <div class="hex-gallery">
            <div class="hex"><img src="assets/uploads/maya-1.jpeg"></div>
            <div class="hex"><img src="assets/uploads/maya-2.jpeg"></div>
            <div class="hex"><img src="assets/uploads/maya-3.jpeg"></div>
            <div class="hex"><img src="assets/uploads/maya-4.jpeg"></div>
            <div class="hex"><img src="assets/uploads/maya-5.jpeg"></div>
            <div class="hex"><img src="assets/uploads/maya-6.jpeg"></div>
            <div class="hex"><img src="assets/uploads/maya-7.jpeg"></div>
            <div class="hex"><img src="assets/uploads/maya-8.jpeg"></div>
            <div class="hex"><img src="assets/uploads/maya-9.jpeg"></div>
            <div class="hex"><img src="assets/uploads/maya-10.jpeg"></div>
        </div>

    </div>
</section>
<style>
    .mdu-section {
        padding: 80px 0;
        background: linear-gradient(135deg, #f8fff9, #e9f7ef);
    }

    .mdu-title {
        font-size: 40px;
        font-weight: 800;
        color: #00a651;
    }

    .mdu-title span {
        display: block;
        font-size: 22px;
        color: #333;
        margin-top: 10px;
    }

    .mdu-section p {
        font-size: 17px;
        color: #555;
    }

    .mdu-btn {
        display: inline-block;
        margin-top: 20px;
        padding: 14px 32px;
        background: #00a651;
        color: #fff;
        border-radius: 50px;
        text-decoration: none;
        font-weight: 600;
        transition: 0.3s;
    }

    .mdu-btn:hover {
        background: #008f45;
    }

    /* Feature Cards */
    .feature-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 20px;
    }

    .feature-card {
        background: rgba(255, 255, 255, 0.85);
        backdrop-filter: blur(8px);
        border-radius: 20px;
        padding: 25px;
        text-align: center;
        transition: 0.4s;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
    }

    .feature-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 20px 40px rgba(0, 166, 81, 0.25);
    }

    .feature-card img {
        width: 60px;
        margin-bottom: 15px;
    }

    .feature-card h4 {
        color: #00a651;
        font-weight: 700;
    }

    /* Hexagonal Gallery */
    .hex-gallery {
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
        gap: 15px;
    }

    .hex {
        width: 220px;
        height: 250px;
        clip-path: polygon(50% 0%, 100% 25%, 100% 75%,
                50% 100%, 0% 75%, 0% 25%);
        overflow: hidden;
        transition: 0.4s;
        box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
    }

    .hex img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .hex:hover {
        transform: scale(1.08) rotate(1deg);
    }
</style>
<?php require "placement.php" ?>
<section class="my-stats-section">
    <div class="my-stats-container">
        <h2 class="my-stats-title text-center mt-5">
            Immerse <span class="my-highlight">yourself</span> <strong>in a Global<br>
                Educational Experience</strong> with peers
            from <strong>65 countries</strong>
        </h2>
        <div class="container-cat">
            <div class="cat-card">
                <img src="assets/uploads/nursing-1.jpg">
                <div class="cat-card__head">Nursing</div>
            </div>
            <div class="cat-card">
                <img src="assets/uploads/b.tech-electric-3.webp">
                <div class="cat-card__head">Mechanical</div>
            </div>
            <div class="cat-card">
                <img src="assets/uploads/nursing.webp">
                <div class="cat-card__head">Pharmacy</div>
            </div>
            <div class="cat-card">
                <img src="assets/uploads/b.tech-electric-2.webp">
                <div class="cat-card__head">Electronics</div>
            </div>
            <div class="cat-card">
                <img src="assets/uploads/b.tech-mechanic-2.webp">
                <div class="cat-card__head">Civil</div>
            </div>
        </div>

        <style>
            .container-cat {
                display: flex;
                justify-content: center;
                align-items: center;
                margin: 10vmin;
                overflow: hidden;
                transform: skew(5deg);
            }

            .cat-card {
                flex: 1;
                transition: all 1s ease-in-out;
                height: 75vmin;
                position: relative;
            }

            .cat-card__head {
                color: white;
                background: #00a651;
                padding: 0.5em;
                transform: rotate(-90deg);
                transform-origin: 0% 0%;
                transition: all 0.5s ease-in-out;
                min-width: 100%;
                text-align: center;
                position: absolute;
                bottom: 0;
                left: 0;
                font-size: 1em;
                white-space: nowrap;
            }

            .cat-card:hover {
                flex-grow: 10;
            }

            .cat-card:hover img {
                filter: grayscale(0);
            }

            .cat-card:hover .cat-card__head {
                text-align: center;
                top: calc(100% - 2em);
                color: white;
                background: rgba(0, 0, 0, 0.5);
                font-size: 2em;
                transform: rotate(0deg) skew(-5deg);
            }

            .cat-card img {
                width: 100%;
                height: 100%;
                object-fit: cover;
                transition: all 1s ease-in-out;
                filter: grayscale(100%);
            }

            .cat-card:not(:nth-child(5)) {
                margin-right: 1em;
            }
        </style>
    </div>
</section>
<div class="container py-5">
    <!-- Heading Section -->
    <div class="row mb-5 text-center">
        <div class="col-lg-12">
            <p class="text-uppercase text-muted fw-semibold mb-2">Excellence & Innovation</p>
            <h1 class="fw-bold mb-3" style="
    font-size: 40px; 
    background: linear-gradient(90deg, #00B894, #28a745, #006400); 
    -webkit-background-clip: text; 
    background-clip: text; 
    color: transparent;">
                Why Choose Maya Devi University?
            </h1>

            <p class="fs-5 text-secondary">
                Discover a world of opportunities where excellence meets innovation and tradition meets the future.
            </p>
        </div>
    </div>

    <!-- Features Section -->
    <div class="row g-4 text-center">
        <!-- Feature 1 -->
        <div class="col-md-4">
            <div class="card border-0 shadow h-100 p-4 hover-shadow">
                <div class="icon-circle mb-3 mx-auto">
                    <svg xmlns="https://www.w3.org/2000/svg" width="32" height="32" fill="white" viewBox="0 0 16 16">
                        <path d="M8 0a5 5 0 0 1 5 5v.5H3V5a5 5 0 0 1 5-5zM1 6h14a1 1 0 0 1 1 1v1.5H0V7a1 1 0 0 1 1-1zm-1 4.5h16V15a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1v-4.5z" />
                    </svg>
                </div>
                <h4 class="fw-semibold mb-2">Top Placements & Global Opportunities</h4>
                <p class="text-muted fs-6">
                    Our world-class faculty and cutting-edge programs prepare students for successful careers with global exposure.
                </p>
            </div>
        </div>

        <!-- Feature 2 -->
        <div class="col-md-4">
            <div class="card border-0 shadow h-100 p-4 hover-shadow">
                <div class="icon-circle mb-3 mx-auto">
                    <svg xmlns="https://www.w3.org/2000/svg" width="32" height="32" fill="white" viewBox="0 0 16 16">
                        <path d="M0 3a1 1 0 0 1 1-1h5.5v1.5H1v10h14v-10h-5.5V2H15a1 1 0 0 1 1 1v12H0V3z" />
                        <path d="M7.5 0h1v5h-1V0z" />
                    </svg>
                </div>
                <h4 class="fw-semibold mb-2">State-of-the-art Infrastructure</h4>
                <p class="text-muted fs-6">
                    Experience modern labs, digital classrooms, and world-class facilities designed to inspire innovation.
                </p>
            </div>
        </div>

        <!-- Feature 3 -->
        <div class="col-md-4">
            <div class="card border-0 shadow h-100 p-4 hover-shadow">
                <div class="icon-circle mb-3 mx-auto">
                    <svg xmlns="https://www.w3.org/2000/svg" width="32" height="32" fill="white" viewBox="0 0 16 16">
                        <path d="M8 0a8 8 0 1 0 8 8A8.009 8.009 0 0 0 8 0zM6.406 12.416a5.5 5.5 0 0 1 0-8.832l.708.708a4.5 4.5 0 0 0 0 7.416l-.708.708zm3.188 0l-.708-.708a4.5 4.5 0 0 0 0-7.416l.708-.708a5.5 5.5 0 0 1 0 8.832z" />
                    </svg>
                </div>
                <h4 class="fw-semibold mb-2">International Collaborations</h4>
                <p class="text-muted fs-6">
                    Collaborate with top global institutions through exchange programs and research initiatives.
                </p>
            </div>
        </div>
    </div>
</div>

<!-- Extra Styles -->
<style>
    .icon-circle {
        width: 60px;
        height: 60px;
        background: linear-gradient(135deg, #00B894, #00CFFF);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .hover-shadow:hover {
        transform: translateY(-5px);
        transition: 0.3s ease-in-out;
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.12);
    }
</style>

<div class="achievement-area pt-40 pb-60">
    <div class="container">
        <div class="section-title mb-75">
            <h2>Our <span>Achievement</span></h2>
            <p>Our achievements reflect our commitment to excellence, showcasing the hard work,<br> innovation, and dedication that define Maya Devi University.</p>
        </div>
        <div class="row">
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                <div class="single-count mb-30 count-one">
                    <div class="count-img">
                        <img src="assets/img/icon-img/achieve-1.png" alt="STUDENTS">
                    </div>
                    <div class="count-content">
                        <h2 class="count">1890</h2>
                        <span>STUDENTS</span>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                <div class="single-count mb-30 count-two">
                    <div class="count-img">
                        <img src="assets/img/icon-img/achieve-2.png" alt="GRADUATE">
                    </div>
                    <div class="count-content">
                        <h2 class="count">1250</h2>
                        <span>GRADUATE</span>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-3 col-md-6 col-sm-6">
                <div class="single-count mb-30 count-three">
                    <div class="count-img">
                        <img src="assets/img/icon-img/achieve-3.png" alt="AWARD">
                    </div>
                    <div class="count-content">
                        <h2 class="count">750</h2>
                        <span>AWARD WINNING</span>
                    </div>
                </div>
            </div>
            <div class="col-xl-2 col-lg-3 col-md-6 col-sm-6">
                <div class="single-count mb-30 count-four">
                    <div class="count-img">
                        <img src="assets/img/icon-img/achieve-4.png" alt="FACULTIES">
                    </div>
                    <div class="count-content">
                        <h2 class="count">250</h2>
                        <span>FACULTIES</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="testimonial-slider-wrap mt-45">
            <div class="testimonial-text-slider">
                <div class="testi-content-wrap">
                    <div class="testi-big-img">
                        <img alt="Maya Devi University" src="assets/uploads/bba-2.jpeg">
                    </div>
                    <div class="row g-0">
                        <div class="ms-auto col-lg-6 col-md-12">
                            <div class="testi-content bg-img default-overlay" style="background-image:url(assets/uploads/testi-bg.webp);">
                                <div class="quote-style quote-left">
                                    <i class="fa fa-quote-left"></i>
                                </div>
                                <p>Studying at Maya Devi University has been a truly transformative journey. The dedicated faculty, advanced infrastructure, and practical learning approach have shaped my skills and confidence. The university’s focus on both academics and industry exposure has prepared me to face real-world challenges and excel in my chosen career path.</p>
                                <div class="testi-info">
                                    <h5>Arti Sharma</h5>
                                    <span>School of Computer Engineering & Application</span>
                                </div>
                                <div class="quote-style quote-right">
                                    <i class="fa fa-quote-right"></i>
                                </div>
                                <div class="testi-arrow">
                                    <img alt="testimoni" src="assets/img/icon-img/testi-icon.png">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="testi-content-wrap">
                    <div class="testi-big-img">
                        <img alt="testimoni" src="assets/uploads/testimoni-2.jpeg">
                    </div>
                    <div class="row g-0">
                        <div class="ms-auto col-lg-6 col-md-12">
                            <div class="testi-content bg-img default-overlay" style="background-image:url(assets/uploads/testi-bg.webp);">
                                <div class="quote-style quote-left">
                                    <i class="fa fa-quote-left"></i>
                                </div>
                                <p>My experience at Maya Devi University has been nothing short of exceptional. The supportive mentors, innovative teaching methods, and ample opportunities for growth have helped me discover my true potential. From academic excellence to personality development, the university has guided me every step of the way toward a successful future.</p>
                                <div class="testi-info">
                                    <h5>Maya Dechen</h5>
                                    <span>School of Engineering</span>
                                </div>
                                <div class="quote-style quote-right">
                                    <i class="fa fa-quote-right"></i>
                                </div>
                                <div class="testi-arrow">
                                    <img alt="testimoni" src="assets/img/icon-img/testi-icon.png">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="testi-content-wrap">
                    <div class="testi-big-img">
                        <img alt="testimoni" src="assets/uploads/st-3.jpg">
                    </div>
                    <div class="row g-0">
                        <div class="ms-auto col-lg-6 col-md-12">
                            <div class="testi-content bg-img default-overlay" style="background-image:url(assets/uploads/testi-bg.webp);">
                                <div class="quote-style quote-left">
                                    <i class="fa fa-quote-left"></i>
                                </div>
                                <p>Maya Devi University has provided me with the perfect balance of academic learning and practical exposure. The modern infrastructure, industry-focused curriculum, and guidance from experienced faculty have shaped my skills and boosted my confidence. I am proud to be a part of an institution that truly prepares its students for global opportunities.</p>
                                <div class="testi-info">
                                    <h5>Rohit Pandey</h5>
                                    <span>School of Commerce & Management</span>
                                </div>
                                <div class="quote-style quote-right">
                                    <i class="fa fa-quote-right"></i>
                                </div>
                                <div class="testi-arrow">
                                    <img alt="testimoni" src="assets/img/icon-img/testi-icon.png">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="testi-content-wrap">
                    <div class="testi-big-img">
                        <img alt="testimoni" src="assets/uploads/girl-3.jpeg">
                    </div>
                    <div class="row g-0">
                        <div class="ms-auto col-lg-6 col-md-12">
                            <div class="testi-content bg-img default-overlay" style="background-image:url(assets/uploads/testi-bg.webp);">
                                <div class="quote-style quote-left">
                                    <i class="fa fa-quote-left"></i>
                                </div>
                                <p>My journey at Maya Devi University has been nothing short of transformative. The supportive faculty, engaging classes, and ample opportunities for personal growth have helped me discover my true potential. The exposure to real-world projects and industry interactions has made me confident to step into my professional career with strong skills and determination.</p>
                                <div class="testi-info">
                                    <h5>Ruchika Tiwari</h5>
                                    <span>School of Pharmacy</span>
                                </div>
                                <div class="quote-style quote-right">
                                    <i class="fa fa-quote-right"></i>
                                </div>
                                <div class="testi-arrow">
                                    <img alt="testimoni" src="assets/img/icon-img/testi-icon.png">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="testimonial-image-slider">
                <div class="sin-testi-image">
                    <img src="assets/uploads/bba-2.jpeg" alt="testimoni">
                </div>
                <div class="sin-testi-image">
                    <img src="assets/uploads/testimoni-2.jpeg" alt="testimoni">
                </div>
                <div class="sin-testi-image">
                    <img src="assets/uploads/st-3.jpg" alt="testimoni">
                </div>
                <div class="sin-testi-image">
                    <img src="assets/uploads/girl-3.jpeg" alt="testimoni">
                </div>
            </div>
        </div>
        <div class="testimonial-text-img">
            <img alt="testimoni" src="assets/img/icon-img/testi-text.png">
        </div>
    </div>
</div>
<hr>
<?php
// Load blogs dynamically
$dataFile = __DIR__ . "/admin/data/blogs.json";
$blogs = file_exists($dataFile) ? json_decode(file_get_contents($dataFile), true) : [];

// Get latest 3 blogs for homepage carousel
$latestBlogs = array_slice(array_reverse($blogs, true), 0, 4, true);
?>

<div class="event-area bg-img default-overlay pt-10 pb-10">
    <div class="container">
        <div class="row">
            <!-- Blog Section -->
            <div class="col-lg-12">
                <div class="section-title-3 mb-45 mrg-bottom-small">
                    <h2>Our <span>Blog</span></h2>
                    <p>Insights and updates from Maya Devi University.</p>
                </div>

                <div class="blog-active">
                    <?php if (!empty($latestBlogs)): ?>
                        <?php foreach ($latestBlogs as $id => $b):
                            
                            $img = $b['image'] ?? 'assets/img/blog/default.jpg';
                            $title = $b['title'] ?? '';
                            $excerpt = substr(strip_tags($b['content']), 0, 80) . '...';
                            $author = $b['author'] ?? 'Admin';
                            $date = $b['date'] ?? '';
                            $tags = $b['tags'] ?? [];

                            // ✅ SLUG FIX (IMPORTANT)
                            $slugText = $b['slug'] ?? $title;
                            $slugText = strtolower($slugText);
                            $slug = preg_replace('/[^a-z0-9]+/', '-', $slugText);
                            $slug = trim($slug, '-');

                        ?>
                        
                        <div class="single-blog">
                            <div class="blog-img" style="height:200px; overflow:hidden;">
                                <a href="blog/<?= $slug ?>">
                                    <img src="<?= $img ?>" alt="<?= $title ?>" style="width:100%; height:100%; object-fit:cover;">
                                </a>
                            </div>

                            <div class="blog-content-wrap" style="display:flex; flex-direction:column; height:100%;">
                                <?php if (!empty($tags)) echo "<span>" . htmlspecialchars($tags[0]) . "</span>"; ?>

                                <div class="blog-content" style="flex-grow:1;">
                                    <h4>
                                        <a href="blog/<?= $slug ?>"><?= $title ?></a>
                                    </h4>
                                    <p><?= $excerpt ?></p>

                                    <div class="blog-meta">
                                        <ul>
                                            <li><a href="#"><i class="fa fa-user"></i> <?= $author ?></a></li>
                                            <li><a href="#"><i class="fa fa-comments-o"></i> 0</a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="blog-date">
                                    <a href="#"><i class="fa fa-calendar-o"></i> <?= $date ?></a>
                                </div>
                            </div>
                        </div>

                        <?php endforeach; ?>
                    <?php else: ?>
                        <p>No blogs available</p>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </div>
</div>

<style>
    .blog-active .single-blog {
        display: flex;
        flex-direction: column;
        border: 1px solid #eee;
        border-radius: 8px;
        overflow: hidden;
        background: #fff;
        margin-bottom: 15px;
        height: 100%;
        /* allows flex-grow to work */
    }

    .blog-active .blog-img {
        flex: 0 0 200px;
        /* fixed height for image */
        overflow: hidden;
    }

    .blog-active .blog-img img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .blog-active .blog-content-wrap {
        display: flex;
        flex-direction: column;
        flex: 1;
        /* make all content wrappers fill same height */
        padding: 15px;
    }

    .blog-active .blog-content {
        flex: 1;
        /* make content grow to fill remaining space */
    }
</style>

<div class="blog-area pt-50 pb-100">
    <div class="container">
        <div class="section-title mb-75">
            <h2>Our <span>Events</span></h2>
            <p>Celebrating ideas, culture, and connections at Maya Devi University.</p>
        </div>
        <div class="row">
            <?php
            // Load events
            $dataFile = __DIR__ . '/admin/data/events.json';
            $events = file_exists($dataFile) ? json_decode(file_get_contents($dataFile), true) : [];

            // ✅ SLUG FUNCTION (ADDED)
            if (!function_exists('createSlug')) {
                function createSlug($text) {
                    $text = strtolower($text);
                    $text = preg_replace('/[^a-z0-9]+/', '-', $text);
                    return trim($text, '-');
                }
            }

            // Sort by date
            if (!empty($events)) {
                uasort($events, function ($a, $b) {
                    return strtotime($b['date']) - strtotime($a['date']);
                });
            }

            // Latest 4
            $latestEvents = array_slice($events, 0, 4, true);

            foreach ($latestEvents as $eventId => $event):
                $date = strtotime($event['date']);
                $formattedDate = date("M, jS Y", $date);

                // ✅ CREATE SLUG
                $slug = createSlug($event['slug'] ?? $event['title']);
            ?>
                <div class="col-lg-3 col-md-6 d-flex">
                    <div class="single-blog mb-30 flex-fill">
                        <div class="blog-img">
                            
                            <!-- ✅ UPDATED LINK -->
                            <a href="event/<?= $slug ?>">
                                <img src="<?php echo 'admin/' . htmlspecialchars($event['image']); ?>"
                                    alt="<?php echo htmlspecialchars($event['title']); ?>"
                                    style="height:180px; width:100%; object-fit:cover;">
                            </a>

                        </div>
                        <div class="blog-content-wrap">
                            <span>Education</span>
                            <div class="blog-content">
                                <h4 class="event-title">
                                    
                                    <!-- ✅ UPDATED LINK -->
                                    <a href="event/<?= $slug ?>">
                                        <?php echo htmlspecialchars($event['title']); ?>
                                    </a>

                                </h4>
                                <p class="event-snippet">
                                    <?php
                                    $words = explode(' ', strip_tags($event['content']));
                                    echo implode(' ', array_slice($words, 0, 20)) . '...';
                                    ?>
                                </p>
                                <div class="blog-meta">
                                    <ul>
                                        <li><a href="#"><i class="fa fa-user"></i> <?php echo htmlspecialchars($event['author']); ?></a></li>
                                        <li><a href="#"><i class="fa fa-comments-o"></i> 0</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="blog-date">
                                <a href="#"><i class="fa fa-calendar-o"></i> <?php echo $formattedDate; ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>


<style>
    /* Equal height cards */
    .row {
        display: flex;
        flex-wrap: wrap;
    }

    .single-blog {
        display: flex;
        flex-direction: column;
        height: 100%;
    }

    /* Limit event title (2 lines max) */
    .event-title {
        display: -webkit-box;
        -webkit-line-clamp: 2;
        /* max 2 lines */
        -webkit-box-orient: vertical;
        overflow: hidden;
        text-overflow: ellipsis;
        min-height: 50px;
    }

    /* Limit event content (3 lines max) */
    .event-snippet {
        display: -webkit-box;
        -webkit-line-clamp: 3;
        /* max 3 lines */
        -webkit-box-orient: vertical;
        overflow: hidden;
        text-overflow: ellipsis;
        min-height: 65px;
    }
</style>

<?php require "common/footer.php" ?>