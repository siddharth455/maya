<?php
$page_title = "BA Hindi Literature in Dehradun | Maya Devi University";
$page_description = "Enroll in BA Hindi Literature at Maya Devi University, Dehradun and gain deep knowledge of Hindi language and literary studies.";
$canonical_url = "https://maya.edu.in/ba-hindi-literature.php";
$og_image = "https://maya.edu.in/assets/uploads/campus-2.jpeg";
?>
<?php require "common/header.php" ?>
<div class="breadcrumb-area">
    <div class="breadcrumb-top default-overlay bg-img breadcrumb-overly-2 pt-100 pb-95" style="background-image:url(assets/uploads/ba-3.webp);">
        <div class="container">
            <h2>B.A. in Hindi Literature</h2>
            <p>The School of Arts and Humanities at Maya Devi University offers a three-year full-time B.A. in Hindi Literature, divided into six semesters.</p>
        </div>
    </div>
    <div class="breadcrumb-bottom">
        <div class="container">
            <ul>
                <li><a href="index.php">Home</a> <span><i class="fa fa-angle-double-right"></i></span></li>
            </ul>
        </div>
    </div>
</div>
<div class="course-details-area pt-130">
    <div class="container">
        <div class="row">
            <div class="col-xl-9 col-lg-8">
                <div class="course-left-wrap mr-40">
                    <div class="apply-area">
                        <img src="assets/uploads/ba-3.webp" alt="">
                        <div class="course-apply-btn">
                            <a href="https://admissions.maya.edu.in" class="default-btn">APPLY NOW</a>
                        </div>
                    </div>
                    <div class="tab-content jump">
                        <div class="tab-pane active mt-5" id="course-details-1">
                            <div class="over-view-content">
                                <h4>COURSE DETAILS</h4>
                                <h5>Course Name : B.A. in Hindi Literature</h5>
                               <p>The course prepares students to become proficient writers, critics, educators, and communicators. Through debates, seminars, workshops, and literary activities, learners develop strong analytical thinking, creative expression, and overall personality development. Graduates can pursue careers in schools, colleges, media houses, publishing industries, cultural organizations, NGOs, and academic institutions.</p> <p>The Bachelor of Arts (B.A.) in Hindi Literature program provides students with a deep understanding of Hindi language, classical and modern literature, literary theories, and cultural studies. The curriculum blends theoretical learning with exposure to poetry, prose, drama, and contemporary writings. Students develop strong linguistic, interpretative, and communication skills essential for appreciating and contributing to Hindi literature.</p> <p>Through projects, fieldwork, literary discussions, and interactions with writers and scholars, learners gain practical experience and enhance their critical and creative abilities. The program emphasizes cultural awareness, ethical expression, and literary appreciation, preparing graduates for roles such as Hindi teachers, content writers, editors, journalists, researchers, and cultural program coordinators in educational, media, and literary organizations.</p>
                                <div class="over-view-list">
                                    <h2>Eligibility Criteria</h2>
                                    <div class="sin-over-view-list">

                                        <div class="course-list-icon">
                                            <i class="fa fa-check"></i>
                                        </div>
                                        <div class="course-list-content">
                                            <p>10+2 in any stream from any recognized board.</p>
                                        </div>
                                    </div>
                                    <div class="sin-over-view-list">
                                        <div class="course-list-icon">
                                            <i class="fa fa-check"></i>
                                        </div>
                                        <div class="course-list-content">
                                            <p>Minimum 45% marks for General category</p>
                                        </div>
                                    </div>
                                    <div class="sin-over-view-list">
                                        <div class="course-list-icon">
                                            <i class="fa fa-check"></i>
                                        </div>
                                        <div class="course-list-content">
                                            <p>Minimum 40% marks for SC/ST category</p>
                                        </div>
                                    </div>
                                </div>
                                <h2>More Details</h2>
                                <div class="course-summary-wrap mt-4">

                                    <div class="single-course-summary">
                                        <h4>Total Students</h4>
                                        <span><i class="fa fa-user"></i> 60</span>
                                    </div>
                                    <div class="single-course-summary">
                                        <h4>Course Duration</h4>
                                        <span><i class="fa fa-clock-o"></i> 3years</span>
                                    </div>
                                    <div class="single-course-summary">
                                        <h4>Course Credits</h4>
                                        <span><i class="fa fa-diamond"></i> 125</span>
                                    </div>
                                    <div class="single-course-summary">
                                        <h4>Total Semester</h4>
                                        <span><i class="fa fa-book"></i> 6</span>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>

                    <div class="related-course pt-70">
                        <div class="related-title mb-45 mrg-bottom-small">
                            <h3>Related Course</h3>

                        </div>
                        <div class="related-slider-active">
                        <div class="single-course">
                                <div class="course-img">
                                <a href="ba-clinical-psychology.php"><img class="animated" src="assets/uploads/ba-2.webp" alt=""></a>
                                </div>
                                <div class="course-content">
                                    <h4><a href="ba-clinical-psychology.php">BA Clinical Psychology</a></h4>
                                    <p>The Clinical Psychology program is designed to equip students with practical skills in understanding mental health, assessing psychological issues, and applying therapeutic techniques to support emotional well-being.</p>
                                </div>
                                <div class="course-position-content">
                                    <div class="credit-duration-wrap">
                                        <div class="sin-credit-duration">
                                            <i class="fa fa-diamond"></i>
                                            <span>Credits : 125</span>
                                        </div>
                                        <div class="sin-credit-duration">
                                            <i class="fa fa-clock-o"></i>
                                            <span>Duration : 3yrs</span>
                                        </div>
                                    </div>
                                    <div class="course-btn">
                                        <a class="default-btn" href="ba-clinical-psychology.php">APPLY NOW</a>
                                    </div>
                                </div>
                            </div>
                            <div class="single-course">
                                <div class="course-img">
                                <a href="ba-psychology.php"><img class="animated" src="assets/uploads/ba-1.webp" alt=""></a>
                                </div>
                                <div class="course-content">
                                    <h4><a href="ba-psychology.php">BA Psychology</a></h4>
                                    <p>The Psychology program is designed to equip students with practical skills in understanding mental health, assessing psychological issues, and applying therapeutic techniques to support emotional well-being.</p>
                                </div>
                                <div class="course-position-content">
                                    <div class="credit-duration-wrap">
                                        <div class="sin-credit-duration">
                                            <i class="fa fa-diamond"></i>
                                            <span>Credits : 125</span>
                                        </div>
                                        <div class="sin-credit-duration">
                                            <i class="fa fa-clock-o"></i>
                                            <span>Duration : 3yrs</span>
                                        </div>
                                    </div>
                                    <div class="course-btn">
                                        <a class="default-btn" href="ba-psychology.php">APPLY NOW</a>
                                    </div>
                                </div>
                            </div>
                            <div class="single-course">
                                <div class="course-img">
                                    <a href="ba-sociology.php"><img class="animated" src="assets/uploads/ba-4.webp" alt=""></a>
                                </div>
                                <div class="course-content">
                                    <h4><a href="ba-sociology.php">BA Sociology</a></h4>
                               <p>The Sociology program trains students to understand social structures, cultural patterns, and community dynamics, preparing them to address real-world social issues through research and analysis.</p>
                                </div>
                                <div class="course-position-content">
                                    <div class="credit-duration-wrap">
                                        <div class="sin-credit-duration">
                                            <i class="fa fa-diamond"></i>
                                            <span>Credits : 125</span>
                                        </div>
                                        <div class="sin-credit-duration">
                                            <i class="fa fa-clock-o"></i>
                                            <span>Duration : 3yrs</span>
                                        </div>
                                    </div>
                                    <div class="course-btn">
                                        <a class="default-btn" href="ba-sociology.php">APPLY NOW</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <div class="col-xl-3 col-lg-4">
                <div class="sidebar-style sidebar-res-mrg-none">

                    <div class="sidebar-about mb-40">
                        <div class="sidebar-title mb-15">
                            <h4>About Us</h4>
                        </div>
                       <p>The Bachelor of Arts (B.A.) in Hindi Literature program at Maya Devi University provides students with a strong foundation in Hindi language, classical and modern literature, and literary analysis. The curriculum blends theoretical learning with practical exposure to poetry, prose, drama, and contemporary writings. Through projects, literary discussions, and fieldwork, students gain real-world experience and develop analytical, creative, and communication skills. Graduates are prepared for roles such as Hindi teachers, content writers, editors, journalists, and research assistants in educational, media, and cultural settings.</p>
                    </div>

                    <div class="sidebar-category mb-40">
                        <div class="sidebar-title mb-40">
                            <h4>School Category</h4>
                        </div>
                        <div class="category-list">
                            <ul>
                                <li><a href="best-engineering-college-in-dehradun-Uttarakhand.php">School of Engineering <span>13</span></a></li>
                                <li><a href="pharmacy.php">School of Pharmacy <span>07</span></a></li>
                                <li><a href="Nursing.php">School of Nursing <span>03</span></a></li>
                                <li><a href="management-and-commerce.php">School of Commerce & Management <span>09</span></a></li>
                                <li><a href="School-Of-Health-Sciences.php">School of Health Sciences <span>10</span></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="sidebar-recent-course-wrap mb-40">
                        <div class="sidebar-title mb-40">
                            <h4>Key Features</h4>
                        </div>
                        <div class="over-view-list">

                            <div class="sin-over-view-list">

                                <div class="course-list-icon">
                                    <i class="fa fa-check"></i>
                                </div>
                                <div class="course-list-content">
                                    <p>Proficiency in the Hindi language, literature, and cultural contexts, including the ability to analyze and interpret Hindi texts.</p>
                                </div>
                            </div>
                             <div class="sin-over-view-list">

                                <div class="course-list-icon">
                                    <i class="fa fa-check"></i>
                                </div>
                                <div class="course-list-content">
                                    <p>The ability to promote the appreciation and study of Hindi literature and culture in diverse settings.</p>
                                </div>
                            </div>
                            <div class="sin-over-view-list">
                                <div class="course-list-icon">
                                    <i class="fa fa-check"></i>
                                </div>
                                <div class="course-list-content">
                                    <p>Strong command over teaching methods for different educational levels</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="over-view-list">
                        <div class="sidebar-title mb-40">
                            <h4>Career Prospects</h4>
                        </div>
                        <div class="sin-over-view-list">

                            <div class="course-list-icon">
                                <i class="fa fa-check"></i>
                            </div>
                            <div class="course-list-content">
                                <p>School Teacher</p>
                            </div>
                        </div>
                        <div class="sin-over-view-list">
                            <div class="course-list-icon">
                                <i class="fa fa-check"></i>
                            </div>
                            <div class="course-list-content">
                                <p>College/University Professor</p>
                            </div>
                        </div>
                        <div class="sin-over-view-list">
                            <div class="course-list-icon">
                                <i class="fa fa-check"></i>
                            </div>
                            <div class="course-list-content">
                                <p>Language Educator (Online or Offline)</p>
                            </div>
                        </div>
                        <div class="sin-over-view-list">
                            <div class="course-list-icon">
                                <i class="fa fa-check"></i>
                            </div>
                            <div class="course-list-content">
                                <p>Curriculum Developer</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php require "application-process.php" ?>
<div class="brand-logo-area pt-45 pb-130">
    <div class="container">
        <h2 class="text-center mt-3 mb-3">Industry Partner</h2>
        <div class="brand-logo-active owl-carousel">
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/1.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/2.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/3.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/4.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/5.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/6.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/7.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/8.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/9.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/10.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/11.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/12.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/13.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/14.webp" alt="brand-logo">
            </div>
        </div>
    </div>
</div>

<?php require "common/footer.php" ?>
<style>
    .single-brand-logo img {
        width: 150px;
        height: 100px;
        object-fit: contain;
        display: block;
        margin: auto;
    }
</style>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<script>
    $(document).ready(function() {
        $('.brand-logo-active').owlCarousel({
            loop: true,
            margin: 20,
            autoplay: true,
            autoplayTimeout: 2000,
            autoplayHoverPause: true,
            smartSpeed: 800,
            responsive: {
                0: {
                    items: 2
                },
                600: {
                    items: 4
                },
                1000: {
                    items: 6
                }
            }
        });
    });
</script>