<?php
$page_title = "M.Pharm Pharmaceutics Chemistry in Dehradun | Maya Devi University";
$page_description = "Study M.Pharm Pharmaceutics Chemistry at Maya Devi University, Dehradun with advanced pharmaceutical research training.";
$canonical_url = "https://maya.edu.in/master-pharmacy-pharmaceutics-chemistry.php";
$og_image = "https://maya.edu.in/assets/uploads/campus-2.jpeg";
?>
<?php require "common/header.php" ?>
<div class="breadcrumb-area">
    <div class="breadcrumb-top default-overlay bg-img breadcrumb-overly-2 pt-100 pb-95" style="background-image:url(assets/uploads/pharmacy.webp);">
        <div class="container">
            <h2>M.Pharm – Pharmaceutical Chemistry</h2>
            <p>The M.Pharm in Pharmaceutical Chemistry is a postgraduate program focused on the design, synthesis, analysis, and evaluation of pharmaceutical compounds and drug molecules.</p>
        </div>
    </div>
    <div class="breadcrumb-bottom">
        <div class="container">
            <ul>
                <li><a href="index.php">Home</a> <span><i class="fa fa-angle-double-right"></i>M.Pharm – Pharmaceutical Chemistry</span></li>
            </ul>
        </div>
    </div>
</div>
<div class="course-details-area pt-130">
    <div class="container">
        <div class="row">
            <div class="col-xl-9 col-lg-8">
                <div class="course-left-wrap mr-40">
                    <div class="apply-area">
                        <img src="assets/uploads/pharmacy.webp" alt="">
                        <div class="course-apply-btn">
                            <a href="https://admissions.maya.edu.in" class="default-btn">APPLY NOW</a>
                        </div>
                    </div>
                    <div class="tab-content jump">
                        <div class="tab-pane active mt-5" id="course-details-1">
                            <div class="over-view-content">
                                <h4>COURSE DETAILS</h4>
                                <h5>Course Name : M.Pharm – Pharmaceutical Chemistry</h5>
                                <p>M.Pharm Pharmaceutical Chemistry focuses on the advanced study of drug design, synthesis, and structural modification of pharmaceutical compounds. The course emphasizes medicinal chemistry, advanced organic synthesis, and structure–activity relationship (SAR) studies, enabling students to understand how chemical structure influences biological activity.</p>
                                <p>The program also covers spectral characterization techniques, modern analytical tools, and research methodology, along with a research project/dissertation, preparing graduates for careers in pharmaceutical R&D, quality control, academia, and regulatory research.</p>

                                <div class="over-view-list">
                                    <h2>Eligibility Criteria</h2>
                                    <div class="sin-over-view-list">

                                        <div class="course-list-icon">
                                            <i class="fa fa-check"></i> .
                                        </div>
                                        <div class="course-list-content">
                                            <p>Pass in Bachelor in Pharmacy from a PCI approved institution with minimum 55% marks</p>
                                        </div>
                                    </div>
                                    <div class="sin-over-view-list">
                                        <div class="course-list-icon">
                                            <i class="fa fa-check"></i> .
                                        </div>
                                        <div class="course-list-content">
                                            <p>Minimum 45% marks for SC/ST category.</p>
                                        </div>
                                    </div>

                                </div>
                                <h2>More Details</h2>
                                <div class="course-summary-wrap mt-4">

                                    <div class="single-course-summary">
                                        <h4>Approved seats –for session 2026-2027 </h4>
                                        <span><i class="fa fa-user"></i> 15</span>
                                    </div>
                                    <div class="single-course-summary">
                                        <h4>Course Duration</h4>
                                        <span><i class="fa fa-clock-o"></i> 2years/4sem</span>
                                    </div>
                                    <div class="single-course-summary">
                                        <h4>Course Credits</h4>
                                        <span><i class="fa fa-diamond"></i> Minimum 95 Maximum 100</span>
                                    </div>
                                    <div class="single-course-summary">
                                        <h4>Total Semester</h4>
                                        <span><i class="fa fa-book"></i> 4</span>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>

                    <div class="related-course pt-70">
                        <div class="related-title mb-45 mrg-bottom-small">
                            <h3>Related Course</h3>

                        </div>
                        <div class="related-slider-active">
                            <div class="single-course">
                                <div class="course-img">
                                    <a href="bachelor-pharmacy-lateral-entry.php"><img class="animated" src="assets/uploads/pharmacy-le.jpg" alt=""></a>
                                </div>
                                <div class="course-content">
                                    <h4><a href="bachelor-pharmacy-lateral-entry.php">Bachelor of pharmacy (Lateral Entry)</a></h4>
                                    <p>The B.Pharm Lateral Entry program is a three-year course focusing on pharmaceutical sciences, drug development, and pharmacy practice.</p>
                                </div>
                                <div class="course-position-content">
                                    <div class="credit-duration-wrap">
                                        <div class="sin-credit-duration">
                                            <i class="fa fa-diamond"></i>
                                            <span>Credits : 125</span>
                                        </div>
                                        <div class="sin-credit-duration">
                                            <i class="fa fa-clock-o"></i>
                                            <span>Duration : 3yrs</span>
                                        </div>
                                    </div>
                                    <div class="course-btn">
                                        <a class="default-btn" href="bachelor-pharmacy-lateral-entry.php">APPLY NOW</a>
                                    </div>
                                </div>
                            </div>
                            <div class="single-course">
                                <div class="course-img">
                                    <a href="master-pharmacy-pharmacology.php"><img class="animated" src="assets/uploads/pharma-cology.jpg" alt=""></a>
                                </div>
                                <div class="course-content">
                                    <h4><a href="master-pharmacy-pharmacology.php">M.pharm - Pharmacology</a></h4>
                                    <p>The M.Pharm in Pharmacology trains students in drug studies, pharmacological research, and clinical evaluation for careers in pharmacy and healthcare.</p>
                                </div>
                                <div class="course-position-content">
                                    <div class="credit-duration-wrap">
                                        <div class="sin-credit-duration">
                                            <i class="fa fa-diamond"></i>
                                            <span>Credits : 125</span>
                                        </div>
                                        <div class="sin-credit-duration">
                                            <i class="fa fa-clock-o"></i>
                                            <span>Duration : 2yrs</span>
                                        </div>
                                    </div>
                                    <div class="course-btn">
                                        <a class="default-btn" href="master-pharmacy-pharmacology.php">APPLY NOW</a>
                                    </div>
                                </div>
                            </div>
                            <div class="single-course">
                                <div class="course-img">
                                    <a href="master-pharmacy-pharmaceutics.php"><img class="animated" src="assets/uploads/mpharm.jpg" alt=""></a>
                                </div>
                                <div class="course-content">
                                    <h4><a href="master-pharmacy-pharmaceutics.php">Master in Pharmacy</a></h4>
                                    <p>The M.Pharm program offers advanced training in pharmaceutical sciences and drug development for careers in pharmacy and research.</p>
                                </div>
                                <div class="course-position-content">
                                    <div class="credit-duration-wrap">
                                        <div class="sin-credit-duration">
                                            <i class="fa fa-diamond"></i>
                                            <span>Credits : 125</span>
                                        </div>
                                        <div class="sin-credit-duration">
                                            <i class="fa fa-clock-o"></i>
                                            <span>Duration : 2yrs</span>
                                        </div>
                                    </div>
                                    <div class="course-btn">
                                        <a class="default-btn" href="master-pharmacy-pharmaceutics.php">APPLY NOW</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <div class="col-xl-3 col-lg-4">
                <div class="sidebar-style sidebar-res-mrg-none">

                    <div class="sidebar-about mb-40">
                        <div class="sidebar-title mb-15">
                            <h4>About Us</h4>
                        </div>
                        <p>Maya Devi University’s M.Pharm in Pharmaceutical Chemistry program provides advanced knowledge and practical training in drug design, synthesis, analysis, and evaluation. Graduates are prepared for careers in pharmaceutical research, drug development, regulatory affairs, and academia, contributing to innovation and excellence in pharmaceutical sciences.</p>
                    </div>

                    <div class="sidebar-category mb-40">
                        <div class="sidebar-title mb-40">
                            <h4>School Category</h4>
                        </div>
                        <div class="category-list">
                            <ul>
                                <li><a href="best-engineering-college-in-dehradun-Uttarakhand.php">School of Engineering <span>13</span></a></li>
                                <li><a href="pharmacy.php">School of Pharmacy <span>07</span></a></li>
                                <li><a href="Nursing.php">School of Nursing <span>03</span></a></li>
                                <li><a href="management-and-commerce.php">School of Commerce & Management <span>09</span></a></li>
                                <li><a href="School-Of-Health-Sciences.php">School of Health Sciences <span>10</span></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="sidebar-recent-course-wrap mb-40">
                        <div class="sidebar-title mb-40">
                            <h4>Key Features</h4>
                        </div>
                        <div class="over-view-list">

                            <div class="sin-over-view-list">

                                <div class="course-list-icon">
                                    <i class="fa fa-check"></i> .
                                </div>
                                <div class="course-list-content">
                                    <p>Specialised Pharmaceutical Knowledge, Research-Oriented Training, Industry Exposure, Regulatory & Quality Standard Knowledge.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="over-view-list">
                        <div class="sidebar-title mb-40">
                            <h4>Career Prospects</h4>
                        </div>
                        <div class="sin-over-view-list">

                            <div class="course-list-icon">
                                <i class="fa fa-check"></i> .
                            </div>
                            <div class="course-list-content">
                                <p>Pharmaceutical industry, Regulatory Affairs, Clinical Reserach, Academia & Teaching, Govt. & Public Sector, Higher Studies & Research</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require "application-process.php" ?>
<div class="brand-logo-area pt-45 pb-130">
    <div class="container">
        <h2 class="text-center mt-3 mb-3">Industry Partner</h2>
        <div class="brand-logo-active owl-carousel">

            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/15.webp" alt="">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/16.webp" alt="">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/4.webp" alt="">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/17.webp" alt="">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/18.webp" alt="">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/19.webp" alt="">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/20.webp" alt="">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/9.webp" alt="">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/21.webp" alt="">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/11.webp" alt="">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/1.webp" alt="">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/22.webp" alt="">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/23.webp" alt="">
            </div>
        </div>
    </div>
</div>

<?php require "common/footer.php" ?>
<style>
    .single-brand-logo img {
        width: 150px;
        height: 100px;
        object-fit: contain;
        display: block;
        margin: auto;
    }
</style>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<script>
    $(document).ready(function() {
        $('.brand-logo-active').owlCarousel({
            loop: true,
            margin: 20,
            autoplay: true,
            autoplayTimeout: 2000,
            autoplayHoverPause: true,
            smartSpeed: 800,
            responsive: {
                0: {
                    items: 2
                },
                600: {
                    items: 4
                },
                1000: {
                    items: 6
                }
            }
        });
    });
</script>