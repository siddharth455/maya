<?php
$page_title = "Best BHMCT College in Dehradun | Maya Devi University";
$page_description = "Maya Devi University is one of the best BHMCT colleges in Dehradun offering hospitality and catering technology programs.";
$canonical_url = "https://maya.edu.in/BHMCT-colleges-in-dehradun-uttarakhand.php";
$og_image = "https://maya.edu.in/assets/uploads/campus-2.jpeg";
?>
<?php require "common/header.php" ?>
<div class="breadcrumb-area">
    <div class="breadcrumb-top default-overlay bg-img breadcrumb-overly-2 pt-100 pb-95" style="background-image:url(assets/uploads/bhmct.webp);">
        <div class="container">
            <h2>Bachelor of Hotel Management & Catering Technology (BHMCT)</h2>
            <p>BHMCT is designed to meet the evolving demands of the industry and emphasizes innovation, service excellence, and customer-centric practices, making graduates highly competitive and industry-ready.</p>
        </div>
    </div>
    <div class="breadcrumb-bottom">
        <div class="container">
            <ul>
                <li><a href="index.php">Home</a> <span><i class="fa fa-angle-double-right"></i>BHMCT</span></li>
            </ul>
        </div>
    </div>
</div>
<div class="course-details-area pt-130">
    <div class="container">
        <div class="row">
            <div class="col-xl-9 col-lg-8">
                <div class="course-left-wrap mr-40">
                    <div class="apply-area">
                        <img src="assets/uploads/bhmct.webp" alt="">
                        <div class="course-apply-btn">
                            <a href="https://admissions.maya.edu.in" class="default-btn">APPLY NOW</a>
                        </div>
                    </div>
                    <div class="tab-content jump">
                        <div class="tab-pane active mt-5" id="course-details-1">
                            <div class="over-view-content">
                                <h4>COURSE DETAILS</h4>
                                <h5>Course Name : Bachelor of Hotel Management & Catering Technology (BHMCT)</h5>
                                <p>The Bachelor of Hotel Management and Catering Technology (BHMCT) is a comprehensive four- year undergraduate degree that focuses on equipping students with the knowledge, skills, and practical experience necessary for successful careers in the hospitality, tourism, and catering sectors. This program combines academic learning with extensive hands-on training to develop competencies in various departments of hotel and hospitality operations, including food production, front office, housekeeping, and food and beverage service.</p> 
                                <p>It also incorporates essential business and management education, such as human resources, marketing, finance, and entrepreneurship, to prepare students not only for operational roles but also for leadership and managerial positions in the global hospitality industry. </p>

                                <div class="over-view-list">
                                    <h2>Eligibility Criteria</h2>
                                    <div class="sin-over-view-list">

                                        <div class="course-list-icon">
                                            <i class="fa fa-check"></i>
                                        </div>
                                        <div class="course-list-content">
                                            <p>10+2 with any stream</p>
                                        </div>
                                    </div>
                                    <div class="sin-over-view-list">
                                        <div class="course-list-icon">
                                            <i class="fa fa-check"></i>
                                        </div>
                                        <div class="course-list-content">
                                            <p>Minimum 45% marks for General category</p>
                                        </div>
                                    </div>
                                    <div class="sin-over-view-list">
                                        <div class="course-list-icon">
                                            <i class="fa fa-check"></i>
                                        </div>
                                        <div class="course-list-content">
                                            <p>Minimum 40% marks for SC/ST category</p>
                                        </div>
                                    </div>
                                </div>
                                <h2>More Details</h2>
                                <div class="course-summary-wrap mt-4">

                                    <div class="single-course-summary">
                                        <h4>Total Students</h4>
                                        <span><i class="fa fa-user"></i> 60</span>
                                    </div>
                                    <div class="single-course-summary">
                                        <h4>Course Duration</h4>
                                        <span><i class="fa fa-clock-o"></i> 4years</span>
                                    </div>
                                    <div class="single-course-summary">
                                        <h4>Course Credits</h4>
                                        <span><i class="fa fa-diamond"></i> 125</span>
                                    </div>
                                    <div class="single-course-summary">
                                        <h4>Total Semester</h4>
                                        <span><i class="fa fa-book"></i> 8</span>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>

                    <div class="related-course pt-70">
                        <div class="related-title mb-45 mrg-bottom-small">
                            <h3>Related Course</h3>

                        </div>
                        <div class="related-slider-active">
                            <div class="single-course">
                                <div class="course-img">
                                    <a href="BHMCT-lateral-entry-colleges-in-dehradun-uttarakhand.php"><img class="animated" src="assets/uploads/bhmct-le.webp" alt=""></a>
                                </div>
                                <div class="course-content">
                                    <h4><a href="BHMCT-lateral-entry-colleges-in-dehradun-uttarakhand.php">BHMCT (Lateral Entry)</a></h4>
                                    <p>The BHMCT (Lateral Entry) program focuses on hospitality, catering operations, food production, and management skills.</p>
                                </div>
                                <div class="course-position-content">
                                    <div class="credit-duration-wrap">
                                        <div class="sin-credit-duration">
                                            <i class="fa fa-diamond"></i>
                                            <span>Credits : 125</span>
                                        </div>
                                        <div class="sin-credit-duration">
                                            <i class="fa fa-clock-o"></i>
                                            <span>Duration : 2yrs</span>
                                        </div>
                                    </div>
                                    <div class="course-btn">
                                        <a class="default-btn" href="BHMCT-lateral-entry-colleges-in-dehradun-uttarakhand.php">APPLY NOW</a>
                                    </div>
                                </div>
                            </div>
                            <div class="single-course">
                                <div class="course-img">
                                    <a href="bhm-lateral-entry-colleges-in-dehradun-uttarakhand.php"><img class="animated" src="assets/uploads/hm.webp" alt=""></a>
                                </div>
                                <div class="course-content">
                                <h4><a href="bhm-lateral-entry-colleges-in-dehradun-uttarakhand.php">Bachelor of Hotel Management (LE)</a></h4>
                                <p>The Bachelor of Hotel Management (Lateral Entry) program focuses on hospitality, food production, and management skills.</p>
                                </div>
                                <div class="course-position-content">
                                    <div class="credit-duration-wrap">
                                        <div class="sin-credit-duration">
                                            <i class="fa fa-diamond"></i>
                                            <span>Credits : 125</span>
                                        </div>
                                        <div class="sin-credit-duration">
                                            <i class="fa fa-clock-o"></i>
                                            <span>Duration : 3yrs</span>
                                        </div>
                                    </div>
                                    <div class="course-btn">
                                        <a class="default-btn" href="bhm-lateral-entry-colleges-in-dehradun-uttarakhand.php">APPLY NOW</a>
                                    </div>
                                </div>
                            </div>
                            <div class="single-course">
                                <div class="course-img">
                                    <a href="diploma-in-confectionary.php"><img class="animated" src="assets/uploads/bakery.webp" alt=""></a>
                                </div>
                                <div class="course-content">
                                    <h4><a href="diploma-in-confectionary.php">Diploma in Bakery & Confectionary</a></h4>
                                    <p>The Diploma in Bakery and Confectionery program is a two-year course focusing on baking techniques, pastry arts, confectionery production, and dessert presentation.</p>
                                </div>
                                <div class="course-position-content">
                                    <div class="credit-duration-wrap">
                                        <div class="sin-credit-duration">
                                            <i class="fa fa-diamond"></i>
                                            <span>Credits : 125</span>
                                        </div>
                                        <div class="sin-credit-duration">
                                            <i class="fa fa-clock-o"></i>
                                            <span>Duration : 2yrs</span>
                                        </div>
                                    </div>
                                    <div class="course-btn">
                                        <a class="default-btn" href="diploma-in-confectionary.php">APPLY NOW</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <div class="col-xl-3 col-lg-4">
                <div class="sidebar-style sidebar-res-mrg-none">

                    <div class="sidebar-about mb-40">
                        <div class="sidebar-title mb-15">
                            <h4>About Us</h4>
                        </div>
                        <p>Maya Devi University’s Bachelor in Hotel Management & Catering Technology program offers in-depth knowledge and practical training in hotel operations, catering services, and hospitality management. Graduates are equipped for careers in hotels, restaurants, resorts, and catering industries, ensuring excellence in service and management.</p>
                    </div>

                    <div class="sidebar-category mb-40">
                        <div class="sidebar-title mb-40">
                            <h4>School Category</h4>
                        </div>
                        <div class="category-list">
                            <ul>
                                <li><a href="best-engineering-college-in-dehradun-Uttarakhand.php">School of Engineering <span>13</span></a></li>
                                <li><a href="pharmacy.php">School of Pharmacy <span>07</span></a></li>
                                <li><a href="Nursing.php">School of Nursing <span>03</span></a></li>
                                <li><a href="management-and-commerce.php">School of Commerce & Management <span>09</span></a></li>
                                <li><a href="School-Of-Health-Sciences.php">School of Health Sciences <span>10</span></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="sidebar-recent-course-wrap mb-40">
                        <div class="sidebar-title mb-40">
                            <h4>Key Features</h4>
                        </div>
                        <div class="over-view-list">

                            <div class="sin-over-view-list">

                                <div class="course-list-icon">
                                    <i class="fa fa-check"></i>
                                </div>
                                <div class="course-list-content">
                                    <p>Apply fundamental and advanced knowledge of hotel operations, food production, service, accommodation, and tourism to manage and improve hospitality services effectively.</p>
                                </div>
                            </div>
                            <div class="sin-over-view-list">
                                <div class="course-list-icon">
                                    <i class="fa fa-check"></i>
                                </div>
                                <div class="course-list-content">
                                    <p>Demonstrate hands-on skills in core areas such as food production, front office operations, housekeeping, and food & beverage service, using industry tools and techniques.</p>
                                </div>
                            </div>
                            <div class="sin-over-view-list">
                                <div class="course-list-icon">
                                    <i class="fa fa-check"></i>
                                </div>
                                <div class="course-list-content">
                                    <p>Identify, analyze, and solve operational and managerial issues within hospitality establishments using critical thinking and data - driven decision - making approaches.</p>
                                </div>
                            </div>
                            <div class="sin-over-view-list">
                                <div class="course-list-icon">
                                    <i class="fa fa-check"></i>
                                </div>
                                <div class="course-list-content">
                                    <p>Adopt ethical practices, demonstrate integrity, and uphold professional standards in all hospitality-related activities.</p>
                                </div>
                            </div>
                            <div class="sin-over-view-list">
                                <div class="course-list-icon">
                                    <i class="fa fa-check"></i>
                                </div>
                                <div class="course-list-content">
                                    <p>Apply principles of sustainability, environmental responsibility, and corporate social responsibility in hospitality operations.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="over-view-list">
                        <div class="sidebar-title mb-40">
                            <h4>Career Prospects</h4>
                        </div>
                        <div class="sin-over-view-list">

                            <div class="course-list-icon">
                                <i class="fa fa-check"></i>
                            </div>
                            <div class="course-list-content">
                                <p>Hotel Management</p>
                            </div>
                        </div>
                        <div class="sin-over-view-list">
                            <div class="course-list-icon">
                                <i class="fa fa-check"></i>
                            </div>
                            <div class="course-list-content">
                                <p>Catering Service</p>
                            </div>
                        </div>
                        <div class="sin-over-view-list">
                            <div class="course-list-icon">
                                <i class="fa fa-check"></i>
                            </div>
                            <div class="course-list-content">
                                <p>Tourism Industry</p>
                            </div>
                        </div>
                        <div class="sin-over-view-list">
                            <div class="course-list-icon">
                                <i class="fa fa-check"></i>
                            </div>
                            <div class="course-list-content">
                                <p>Cruise Industry</p>
                            </div>
                        </div>
                        <div class="sin-over-view-list">
                            <div class="course-list-icon">
                                <i class="fa fa-check"></i>
                            </div>
                            <div class="course-list-content">
                                <p>Retail Management</p>
                            </div>
                        </div>
                        <div class="sin-over-view-list">
                            <div class="course-list-icon">
                                <i class="fa fa-check"></i>
                            </div>
                            <div class="course-list-content">
                                <p>Event Management Companies</p>
                            </div>
                        </div>
                        <div class="sin-over-view-list">
                            <div class="course-list-icon">
                                <i class="fa fa-check"></i>
                            </div>
                            <div class="course-list-content">
                                <p>Hotel Manager</p>
                            </div>
                        </div>
                        <div class="sin-over-view-list">
                            <div class="course-list-icon">
                                <i class="fa fa-check"></i>
                            </div>
                            <div class="course-list-content">
                                <p>Front office Manager</p>
                            </div>
                        </div>
                        <div class="sin-over-view-list">
                            <div class="course-list-icon">
                                <i class="fa fa-check"></i>
                            </div>
                            <div class="course-list-content">
                                <p>Housekeeping Manager</p>
                            </div>
                        </div>
                        <div class="sin-over-view-list">
                            <div class="course-list-icon">
                                <i class="fa fa-check"></i>
                            </div>
                            <div class="course-list-content">
                                <p>Event Manager</p>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php require "application-process.php" ?>
<div class="brand-logo-area pt-45 pb-130">
    <div class="container">
        <h2 class="text-center mt-3 mb-3">Industry Partner</h2>
        <div class="brand-logo-active owl-carousel">
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/1.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/2.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/3.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/4.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/5.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/6.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/7.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/8.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/9.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/10.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/11.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/12.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/13.webp" alt="brand-logo">
            </div>
            <div class="single-brand-logo">
                <img src="assets/img/brand-logo/14.webp" alt="brand-logo">
            </div>
        </div>
    </div>
</div>

<?php require "common/footer.php" ?>
<style>
    .single-brand-logo img {
        width: 150px;
        height: 100px;
        object-fit: contain;
        display: block;
        margin: auto;
    }
</style>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<script>
    $(document).ready(function() {
        $('.brand-logo-active').owlCarousel({
            loop: true,
            margin: 20,
            autoplay: true,
            autoplayTimeout: 2000,
            autoplayHoverPause: true,
            smartSpeed: 800,
            responsive: {
                0: {
                    items: 2
                },
                600: {
                    items: 4
                },
                1000: {
                    items: 6
                }
            }
        });
    });
</script>